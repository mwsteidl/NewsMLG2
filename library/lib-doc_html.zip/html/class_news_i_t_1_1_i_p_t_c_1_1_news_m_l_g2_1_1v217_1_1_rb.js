var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_rb =
[
    [ "Rb", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_rb.html#a4229274900c06bd2c60bc9564fe8be81", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_rb.html#ade1686eed9a3c191619650e8e5d5285d", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_rb.html#a438cccef87396141e5725107b507398c", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_rb.html#aa94d23e806ca6bfd602c63b067df222c", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_rb.html#a439e5adf072501cb4eb82420950afc5e", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_rb.html#a7c0c0f66031b0f5fbda0ea2741f42574", null ]
];