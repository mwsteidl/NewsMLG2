var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded =
[
    [ "Founded", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a182e3d7dfa37df7090e4270c3fcb820a", null ],
    [ "Founded", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a19898e767a3d446bb10109227b19aeb3", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a01d007e98e144047484678033e8bd6a2", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a00ca3d390a14a6570afa351a9d200466", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#aefe260ab1ec755b147768b3b8c257928", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a8cf9cdf13cc66e5dea0d3202a58076e5", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a77d2788fc38db628da894d43e00a7233", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a289c56c99b375eefc0257fb4f82f3569", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#aa5ede03b6f8ec281dfa886eb920caf38", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#af973deb9fa6827cdf3798e758bcf9614", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a91b58ca51191abb199a3f078020901f8", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a1f99815fd7b7815323ddc14d0826e5c4", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a7f4e11b5acbed9b4dfb244fa48d0b259", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#a2cdc2c17050f315572091a6b6a0b068b", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_founded.html#af8a7794d71d43a1dd4b31af07f3c22cc", null ]
];