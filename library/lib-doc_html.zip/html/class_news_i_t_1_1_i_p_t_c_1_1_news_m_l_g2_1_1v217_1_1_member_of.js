var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of =
[
    [ "MemberOf", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#ac389f666c605f86becd7c80cff55ff14", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#a4e8c94f9dbc19aa36266731d072778d1", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#ac9ae9821d2ebc762038ac7001d268f1e", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#aa8c24e9b3581dc8adbfd6e0780069039", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#aedaca099c082517f9c0a6da19c0ca7c3", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#a3d591e25c43cbee650360211d3528d64", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#abb19174cd2fcc80d71a89908369add7a", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#ad4a43d804c91d4d2f20f28d78b1a9d26", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#a49bd448487cc90c2981bd65d8d4dd041", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#adea3fcf9f130d1a14c24df4d2ba94528", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#a209a72f8f20d0515bd0003c8880539e0", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#ad93cc991aaae1381acc507b2064d450f", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#a907ba02b3d513fa8f28cd483daa61361", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#a053004d7597f01f269f79faf9571b1f4", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#a8d25652b2d30af4facf946f55278f0a1", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#ad6731e272fab3eaac795cd880edba48d", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#afc9b7c8ed4ef27037ccdb4c2395bd781", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#a40a73770d41672174968911e0b61198e", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_member_of.html#aa132a2b929450cb0e629a96b1172d606", null ]
];