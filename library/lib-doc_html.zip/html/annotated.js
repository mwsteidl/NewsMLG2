var annotated =
[
    [ "NewsIT", "namespace_news_i_t.html", "namespace_news_i_t" ]
];