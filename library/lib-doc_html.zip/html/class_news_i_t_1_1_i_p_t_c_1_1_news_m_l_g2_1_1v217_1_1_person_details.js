var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details =
[
    [ "PersonDetails", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#ac588204b891a6b4977d85f46eb1fc733", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#a6cdb82ce3ddce1abca2bc18674818dfb", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#aecf14ebca4adcbc01507d34988e04126", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#a30d1de892cc5c9bfb25b9f2631b17bc5", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#a6ed5d1138ee8b0c4ea34f6207075b910", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#ac3da2af1e360b7f8d5981f1b5f46e625", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#a97fdc0993cead055b4f94d778ce7283c", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#a5baae350a48e9ed87a894894c2b588ea", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#adae3ac915996379bc2676a526cfc68c8", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#a2416e0a5b63be3e13e8559032591d238", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#a189d63204e6ec285ac1eaa8c4fe64601", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#afa71568b41306700fd453183652b7000", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_person_details.html#ae0f2d880a7ee56d27e010cc1e977522e", null ]
];