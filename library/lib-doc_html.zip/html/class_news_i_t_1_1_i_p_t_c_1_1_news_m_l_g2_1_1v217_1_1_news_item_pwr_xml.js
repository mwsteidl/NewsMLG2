var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item_pwr_xml =
[
    [ "NewsItemPwrXml", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item_pwr_xml.html#ab66b414b7347aead3ce29f6a0d55bdeb", null ],
    [ "AddContentSet", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item_pwr_xml.html#a02d71ab0721c755ab85d02933cafd407", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item_pwr_xml.html#ac5a916da4a2dcfa529784c331d338d62", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item_pwr_xml.html#a2dcd7907ed81be0e90eeb077d529d23e", null ],
    [ "NameSeqNiRoot", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item_pwr_xml.html#a100c5f330db35bbe798078823ed53555", null ]
];