var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details =
[
    [ "EventDetails", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#a895d8e4459a3790ac69d2b0df31c4c0b", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#ab6d19c4f58243da722eb86bed9e8b7f9", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#a9544fc4e746f7ff73cec4c8232597838", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#a5746a9f6a78fa31ca5178e20cad5bb58", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#a30994489b0d45fcf40344249f243c7b4", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#ae3eca434dbc1935d9f04729595872df5", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#a592b003634151c05f6dfc20030768be4", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#a8cb754cf2bd95ea0d93785fd34de0099", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#a8b1496c8a6f5012312e612f10f3ce626", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#acde102657b3a6d184e0962d126aa6d7d", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#ae0fe2ccf73e71189d4353a47c067cfb6", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#ac36f02b6721816055111b4d0b20abbae", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event_details.html#a81d79f71ff6a2bd480316c58757c29d8", null ]
];