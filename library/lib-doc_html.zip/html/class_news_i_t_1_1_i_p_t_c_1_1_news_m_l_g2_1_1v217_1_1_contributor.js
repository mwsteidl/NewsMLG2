var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor =
[
    [ "Contributor", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#ac07df318319f7908ea1b869143f07acf", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#ae34f56d66cc8831365120913bc3ae1b5", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a229fa798d1f7def2d004779df4915fad", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#abe671db714078bb889178a676cc3b9ed", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#abb5bb30225de131539b4e1d918df33bc", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#af5a73ad4b6a97b11f50e159a15120274", null ],
    [ "jobtitle", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a79de740678501423fa3a5e69a30abd71", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#aca7448d12a26033e47e0834b385e4d80", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#ad9e3ad0daf9adfca612d49cca90a20cc", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a821363bba915a39311c39f72f99ef292", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a75f79006fb13248aff44ed10652ee909", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a4a3380ecb86245eac40098041670fda2", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#af6751136472c4f96d84a03a5bd2a9c4c", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#aafa5480383fc4cb3a11720e5f15e6ce2", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a52c85633e7ad7c10d0a4c674071bd895", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a7dbc5b2550e93c7a1d629bfe9aef8e1d", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a5e0c8bdfbc3c9ce67d6d06239cbec6b3", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a16a745ffd6a96878e782dbbab9c9050c", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a25870f94286e0b7edcd2b82803bfa46a", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a425249036ae28f6c88587cbd1272f5de", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contributor.html#a4061dc9a9f6e23008cac3c85cdc931e1", null ]
];