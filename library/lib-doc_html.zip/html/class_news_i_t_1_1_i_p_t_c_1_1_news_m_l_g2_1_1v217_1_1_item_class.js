var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class =
[
    [ "ItemClass", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a009ed500252aa5332dc20fa2ec661d3b", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a4f97e6d9ccf5c187c13bf5535a3327d7", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#accf8f0b1a66816a90c725ab34df6ee51", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#aeffbbb2dc90896c65332dc1abcf69221", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a429911df443ab9fe4528206c8649c012", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a176a8c95bb5eba3216961aae600d5fd8", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a89264a947d59f06640b5d38469462c88", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a026619376766e12a45ef29e334e23a1f", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a96fdd770dac521c901b9076501a0c118", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a8e861e96b6c3ce5cf4be7e810032fbed", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#ab5d02d598c72dc45b7cc3a8dac43a08a", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#ad8b0cf7b5452e9d1c3987b310254f39e", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a44f210f3ef1dfe351433eb6685086622", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a9563a00023f91b7df34ad9bb1a5371c4", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#aa6169aa0b8ae2de0d25ce2104cf288aa", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#ac9135777851f763890c90658e7914742", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_class.html#a641b5da6dc11cfe2a433449702696780", null ]
];