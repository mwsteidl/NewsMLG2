var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline =
[
    [ "Headline", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#afc898e149409034c42b0e8bd4e9ffd59", null ],
    [ "Headline", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a7e5d378bf83c2a155255a128e25ac7fc", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#acc014c1df686565044a21f665001a09d", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a171d782ed7120e0f35893e1bdcb3a6f9", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a7ffee6f28ac5c2d36e13c38b83e3729b", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a3e66f46f649609d3089ccbd3c8a4907b", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a0b49733b5a8cbc5a30412ec0368aae71", null ],
    [ "media", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#aa130424312c281f6962f28d9a5107a30", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a04b1058241d120c0c8716fec25d390bf", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#aa4843b3baa454510d6386f03e9313593", null ],
    [ "rank", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a29a92c18b31a071f0fdc2f71060df098", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a41308f67ffa3d5c79f34448f4878f583", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a3789125487d834f5d71bc064af115288", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a0c0781c7e3e3b764f6529bbced727008", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a32bc1530eee3c2eb951edd2885bc1411", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#af11ad9625149b0b02a020a18d25488b6", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a63a1524b4cd2b9041b579cdc0299eb59", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a75c80a86535cddc5ff00fe07f17250ad", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a41edbee4afb9459f535c691bbcf2a7e2", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_headline.html#a579a5d2e9ff669ab28f167d673044ae9", null ]
];