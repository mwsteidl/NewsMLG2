var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description =
[
    [ "Description", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#aec36898c2d3d882ea2d7f9138f11d6dd", null ],
    [ "Description", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a54c0715e32300c0392a2504635d1b70c", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a25b4bb0c65688a95a7947b0ad1e5b4a1", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a1e1a516c67daae4920073982cb304950", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a325f8511a8c523fef2f703fd554fe64f", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a3929bdec5f50ff82603151b636058382", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a8b661d5739f080ed7259204c8a2f8de7", null ],
    [ "media", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a40d820d9ca2095a4d7d3eefb1a4e2424", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#af3e37723153d89d0ae95631b2c90ce56", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#ac490a53c5b01dfc113f2aee5967fe99f", null ],
    [ "rank", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#abd99a31c2a47a4e6a59da4ce5c689e91", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a972dd802c4d2a80329beaae8ee560d21", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a2467a3667e48c5735f9013be9f9df572", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#aa65f591871f51dbc38df4c679a03516b", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a32e225eee7f8d9cd7dd439b76043465e", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#ab7f7d777a30f0ecee881c1d3e5afc9c9", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#aeba854ba47934a8bb72596b0c22c4290", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#a83e84deb247836dbbd9ec652300594da", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#ab3a7736d0ef7a0a0d1a2d38ca01d0a61", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_description.html#ad19a23686392814c58ba8df96708b4e3", null ]
];