var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br =
[
    [ "Br", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#a2ab270bde39beaa403e6b2149758f54d", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#a3594e72c9f67c04706b7bbf44c5d8e50", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#ae4a7c28e674ae7de9a6848d8aa0137f4", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#a71a8c79bb2337def334fd06b2a2d4270", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#a3fcf687da56b13e315e2747298b671b1", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#aea0e04adc22942dae11afa9f2ebf9356", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#a673abb633a49b352d42eb91b00d30251", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#a44a60ef1999eea7f4f45446a58a21dcc", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#a28e94d3e372ef080ca0093689f30c95c", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#ad5721b541310c2008c9df96b2ba6c39e", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#ac160a72ec2b91dbbbcfe2275f0627e08", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#a30de4e7b87ab510258664730c7e480bb", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_br.html#a32c8d60b57cd19c187b7faa3cc5bb4ac", null ]
];