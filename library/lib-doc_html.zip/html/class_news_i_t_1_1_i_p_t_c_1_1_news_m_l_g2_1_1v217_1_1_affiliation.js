var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation =
[
    [ "Affiliation", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a8fabba730fc9dd964ce6a427fa0ed94b", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a4c6612e1c5128b2237100815ef814679", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#ae416d61bdefcf9bfcd93cd58036118d7", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#aa67b03422487b03e7506988b65554965", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a62e8bc1949ed7cc39f7638e863097676", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a575ed60dec873e609ef3a884a8a3df53", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#ab34d9ec624750ab744c0a16603c03701", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a5cc63f5f83873fcef431fbc5a448cf9f", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a7e314301798cb0efe9c0fbe140586360", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#ad5fb3eafe2741b716ffaae5c0bd1d091", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#adeaa6c5846f99619c4b0dd8056b12c7b", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#adbeb6cc220a10769191cc2a2c126184a", null ],
    [ "validfrom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a9e42048c3220e7f66d68e11b5220dd80", null ],
    [ "validto", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#acb480c393cf6728d5b81fbad0670fe13", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a9323083351546b84f8c2b1d980f6b703", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a94460a559db5c9580b326fc2071661bc", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#adf7af5a5d556c327e3c979e90d10728c", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#ae4ff9b44b087c7bc5f742c4defbbdeaa", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#a0e2697fc91885a3e70592854dfdef6fa", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#ac6eefa3edebc7d1481ec4f547f4c9c5a", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_affiliation.html#ac6b63efb7006e51c28771f19b92f9eff", null ]
];