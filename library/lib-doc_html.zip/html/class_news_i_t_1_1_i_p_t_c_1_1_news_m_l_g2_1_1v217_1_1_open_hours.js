var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours =
[
    [ "OpenHours", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a3895f56db4b7ceecb928a996fa04254f", null ],
    [ "OpenHours", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a7177a1d407e4733be8637be99fb41d42", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a3c61eda988ce36f5e15a14d69d385cd0", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a5fefc2b89c957269771af031fb54e268", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a7a544727af58f7638eb07af667440b13", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a6f28b437630eb8223c9a5933a055e916", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a077f5abc4c3e013feecff120874d70d2", null ],
    [ "media", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a3b13aa2f7ead665c4424d2bd20ea6d5c", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#ab4fc966a7570e54af85e0ab3f255187f", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a8c7caeb781976699db0fedcfef87bd89", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a1d329af597cd05c8233c30df3bf3b579", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a9518c36be87a3e65bfd3b969a9634045", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#ade9caffeecd1cd94b3eceb9c58840a01", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#aff485c9658b09eae5f60ea2392d1c3c5", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#ab5bd0e1cedcdd4ab3eb856f16444b1e7", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a9afb8765ff062f0ac05e2317f906687d", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#aba39ba30ff84c57a7e8de30f6914d79c", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a06c965c53ceb385108fa99d7991a8a98", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_open_hours.html#a9fcb55f5a958400e065efe1910dcab4a", null ]
];