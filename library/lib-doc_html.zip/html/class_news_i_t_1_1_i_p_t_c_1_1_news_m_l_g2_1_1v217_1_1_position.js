var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position =
[
    [ "Position", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#ae14a86c10859c1276a8ae4faf1c90a78", null ],
    [ "altitude", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#ac27c00fb42467439292ac5d97adb3c50", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#aba8d5a887bc7a77cff93d7f65f58d8e7", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#af31b83017835b5529c868d6677195762", null ],
    [ "gpsdatum", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#a90d5aa1507864d8b28514cd8a33d2935", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#a0862ba09c69baacf482dc543a5a98deb", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#aa3dc398b45c853ddad7948f8427d2f67", null ],
    [ "latitude", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#a3464db587787bda4939affd18231817a", null ],
    [ "longitude", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#a381d21d1eb1b7e1f702e8ff174711e2f", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#ae2c916117e407130cad2c43b782170d0", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#ae2c97c019537bb93f52ea7e06ffd6485", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#a5561dcc918f9df99442bb982a4ab1721", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#af1daff45ea5e702c8c0b81aa531df02c", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#af77b6ffcc82d21f407d2468bc94e5e96", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#ae63771fef61a9d28c3d8bbcd5fdf7d41", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#aa32fcae290a1f7c96fd3706068820786", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_position.html#aebf0dc44d641a9ce8feef9d9a3b62976", null ]
];