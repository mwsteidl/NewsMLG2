var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword =
[
    [ "Keyword", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#ab24420fbfe8fb8bb1ac6e2545bd199d4", null ],
    [ "Keyword", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a79443b5773221195b6e2d42316e4419d", null ],
    [ "confidence", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a030a6270fb91be21d2b124be11cbba9b", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a94db6fa0827f63c5a9c3926834f69b21", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a041f6ff5f65530eecdb6142919bd1618", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a4bb1701dee32226e6570167840e5081e", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a36f683c545e69aee09e9dce45cc6fcf5", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#afd477669993c7099d9df05d6fcf058da", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#ae64153157836b103f67b0dba3bd0b6af", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a2661d835198dd74e4feed638bfa4384c", null ],
    [ "rank", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a6941ae90a71bdde5269bf3c7adce8fd9", null ],
    [ "relevance", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#aba9b98006ff9aa12699eeab7eaaf4aab", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a0c3d45a29da9f1ada9ab1380db30eaf2", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#ac14810881cc865332a258102f8810cbc", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a0920acf378ac4b488f11b3157fe3bc94", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a2d9fb001af00c2db7d669b2e3361b63d", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a095132196545480edd4dfd975aa032e0", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#ac0479f945356b5ee479b383852bf5935", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a8d2e5e166aa54f3e0251d6f61a64eb37", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#a8b6e54489bd9b5b0723059a5997346ba", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_keyword.html#ac1eb70576215cc09506ff787892da035", null ]
];