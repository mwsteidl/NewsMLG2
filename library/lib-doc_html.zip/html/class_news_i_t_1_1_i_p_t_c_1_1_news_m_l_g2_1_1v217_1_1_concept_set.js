var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set =
[
    [ "ConceptSet", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#a64728b3686888b2fb7f2fc75417776a0", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#ab14af2e2eb67a109ca23839c40b719b1", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#a04859317eb51360e12f7851d09f48d52", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#a44942716d4900f4b4fa2c750f32e8eaf", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#adf252fcddfdf1158c6a2d9e191dea06f", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#a7fd46e5ed832d5e8e99085a7a43ec24e", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#aa425040467f45ca54e28f226324b15d6", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#a6ba2ed53202dff82958479ef32224469", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#a42811036b7a0aeff20f8d7b883865d86", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#a7a49e894dc6d863757c68e2b2ae2e6f7", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#a5dd70521a4cc62a23065180d3137cdcb", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#a9d01b9cb7bd9ce6e83bd23506bd26c71", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_set.html#ad9a7e5d2880b3d86ccd3dfe5acd3525d", null ]
];