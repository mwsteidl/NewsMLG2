var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator =
[
    [ "Creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#ab1d59a60b2e1129b1e084a8daae47d13", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a4dc6c0c48986b7d55b5cb4019be4208b", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#af9f99055b131c41a59dfc75ce37054aa", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#ac4a6a773de1a13329b7ea70e466a8fe5", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#af775c59b8d9a117c65373f54aac58043", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a971ae6dfe9f8ce6b884af767661b567f", null ],
    [ "jobtitle", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a101ae50df90b0adc62e3dd96905ab440", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#ade971487f78e1f21437ba53c02198fda", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a0f99379267d3d101206eecc2073aebab", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a76eefa9e210bc64bcfd3ae387b6b31a5", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a6a511c364b810e7e4c040fc571eb8aeb", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a75e403f5df00fc6157a5f8add6821b0e", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#ad41863a3bf1b017e1550e3407a78a887", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a74a05018d6f3132e06d3ecc5bb2b0c5f", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a0153ade46dea70195127a3ecf86b8ab1", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a17e13da8c26c868de7e7a4e30b80002c", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#ad3563a4212d89ccea8db15114a843e49", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a90f2ef1f60f2316d6be7204d5ddecc80", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a74852b2805d7461c01254906ed7a8832", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#a7bf12e508d94a0351ed0871cfe7e428d", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_creator.html#af30abe0e1dba0144ab1558f37e901e13", null ]
];