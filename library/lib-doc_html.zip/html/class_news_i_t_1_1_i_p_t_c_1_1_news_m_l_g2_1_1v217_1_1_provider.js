var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider =
[
    [ "Provider", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a04ac407eb1fd4e6449a22bf3ef46e34b", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a23c97fe17dedf30fee0b0ec405f8f342", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a151ab97019a5ae472cc2a895ff139031", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a8214dd8c6adc20709456dcc70e3fbf16", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#af0e96381dd26ae9cf1d08876c9cb4efc", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a46a57c4201f760ab3c0101b2c120ed66", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a58b7e18a9b70cc1080afa63c9f1d35db", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#ad6794e3f9d197d82de42c19005890537", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a75b97dd87d5d172fbe87a338b8ff7615", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a8c65d8f86c6e87bc4fb0a5ca2b38d835", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a3c7f3738337f9900304097d7c5bcfdf6", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#aa70bed23ce40f7b2e0da5b34644bec6f", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a56f0da2132bfa5207183a69c6749580b", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a1dab8a5ca296bacdadd56e5ec7cfb8a2", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a40bd216becf6b4ff9336786bd7eac918", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a9556d72adfd1432aa06c211f254584ce", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a55407615b0d7c13f232b0523d86bf198", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#a03057ceb5fde1a4c03314cebcb965ef1", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_provider.html#aff929a97e3f49d8bde507b9b3cba4804", null ]
];