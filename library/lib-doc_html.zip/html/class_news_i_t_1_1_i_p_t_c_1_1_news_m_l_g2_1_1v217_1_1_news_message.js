var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message =
[
    [ "NewsMessage", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message.html#a341c694224ae4793fb2c80babd098ef4", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message.html#a429d8a2e7740ce16861b852ce2753f5b", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message.html#ad9a6300a307c0b214fc882c1a60c2f67", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message.html#a540923d7b6de53037c451895b85ca992", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message.html#a7427a6dfdfcd85b4243ab85da007b5ba", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message.html#af65f244d38ec35a2996ffde2b5c2d68a", null ]
];