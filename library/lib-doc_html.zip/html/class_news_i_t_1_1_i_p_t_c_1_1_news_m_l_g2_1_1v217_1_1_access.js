var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access =
[
    [ "Access", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#ace973c37fb11e256217f6b1579388c62", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#abf6c1a6dec9050bb55c9018bf68089c8", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a4583958892c3f7fa6b93c8b54f9e5239", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a002512b5999a6fa2c9fe9dfcf6a8e048", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a8c29fbc0d05275f2bfd7d7325faef9d8", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a338373bf1e1918b50b1ece79c5316013", null ],
    [ "media", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a721bcbfb6f2f3689d8cd7066991a2444", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#abafdb510ea2babfb80b6dd5e4fec395d", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a4ccd3a739da3299e82d03f8dcec4d6c3", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a026a579b7a88bc17a1cc705f15dfaf58", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a4ab1e3fe859f8db169e855170cf27678", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a164968fae04fa484cade7eb3339fbec0", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a915a51b3cb781f45a65c3fd8d427637e", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#af23a92a9a828fa0f01556cb1c48c2b2d", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a0618e22e05c3884abe5b5645ba14e0cc", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a1fbc00f3044c37072499fb69d84187c7", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access.html#a36a938127235ff10a4248fcdb4af84b8", null ]
];