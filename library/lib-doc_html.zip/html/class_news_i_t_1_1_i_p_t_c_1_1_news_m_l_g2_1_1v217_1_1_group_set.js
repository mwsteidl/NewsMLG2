var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set =
[
    [ "GroupSet", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a7110734498e7f364fc15e3dca395ebe3", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a03e065607a56f7e0ea23e275fb92080e", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a80c62654409e3409d5d4a66fcbcda5e3", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a218609e4d51e2b3feb584a6ecae69523", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#acbe5964913f19efe058c417757bfc39b", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a5c7063e5d658eec8537f0eea95171f25", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a8822cbbeaa09d15009f41c0020738cdc", null ],
    [ "root", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a51b903979cfb0e5ee1df8177d7cf9350", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a1e678b9b838c151172384423d6d46fc5", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a751ed81803c1761df93905f57598498a", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a74f792f3f4f523b35ecb2ecb8daa2a5e", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a54ab184a856f9836c765cc040a3deb42", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a22454ba27673be0a4655961a9b1ce944", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_set.html#a8932deae8c778231a431ed9d78f1ae9c", null ]
];