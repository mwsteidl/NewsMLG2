var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash =
[
    [ "Hash", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a2bacc46ef00c9df6d19faf6a9a51d467", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a5131b68a6d87e0fa48d41c13ebe3816b", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a7820544e1db43e6ce246670235607eb8", null ],
    [ "hashtype", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a42ec245b9b93babd52f7cec5db2d5285", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#aa13be41fe5968e977b4d563fd463b37b", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a6c8d314cbd77e797230c53e83636559a", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a040fbd434fa1145f261c87d2cd5f90ab", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a19abfc50f55f579d9f0ea326bb2494c6", null ],
    [ "scope", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#aca6ba3c929b77f229f2c5d2d6a933637", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#abe7c7295f2c20b4eebfeae2386237d95", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a64c71fe3cb5a378fe10ff8eadfc6faa7", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#ac6b4724fcc43044ab12b78c0fd79202a", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a9b52954e48cf56600fc2d61de5e40f53", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a073f9f516d474590f96c6246094ff946", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hash.html#a463b3efa2531061cdf4ab7a66f01d9f8", null ]
];