var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop =
[
    [ "GroupStructProp", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#a47126d74d3512a8de502c4984c85bac3", null ],
    [ "GroupStructProp", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#a817044fcfe0133366604cd82fb9080fe", null ],
    [ "GroupStructProp", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#afac94dce9c91e7ff0299b7fb754e712d", null ],
    [ "AddGroupToPackage", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#a1c0324b2c8cb9a1d7e8c28914baa0dea", null ],
    [ "ConceptRefs", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#a507c8bc40c7c912a7f737073d8bded90", null ],
    [ "CoreGroup", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#a4b56cf6f38031601f37a197a04ff62a6", null ],
    [ "EdNotes", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#accd522b149ad3f3f3e8856653ad274f8", null ],
    [ "GroupExtProperties", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#aa55363880f34c945e69d09441b6de962", null ],
    [ "GroupRefs", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#a24907b479e560da50e4b60258ba5a675", null ],
    [ "ItemRefs", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#aaedf1bee6b81f1d1675a78aba90d72a2", null ],
    [ "PblPath", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#a476cf3d6af0146dca2582ff911170944", null ],
    [ "Signals", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#ad2d7276f34c314c702be689af9a4f9c0", null ],
    [ "Titles", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_struct_prop.html#a1cb7e64e45961c195180f65f3f30bb0b", null ]
];