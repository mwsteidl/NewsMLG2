var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop =
[
    [ "Hop", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#a922c30722ee1c691c8161be2a2eb95cd", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#a62340890ee735ee4a6ab83ba0c5e7fa3", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#aeb1193b34247481fd92252ccf94759a8", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#a7eb347db7b6497c72b01a3d86400da51", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#aa9f80a2b0328b46c6fbcfc64bc5e010c", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#a873e650532a7834c028d2fc22e943b81", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#a59a12762ee3d8a43927e3a4362714893", null ],
    [ "seq", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#ac2763bbcd44740804252f68403660370", null ],
    [ "timestamp", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#a2276c50080af88d0bf074350ca4c3f09", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#aa2f13d4aea207946492241e1a5992d89", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#a63b2a723329b721dcfc589c9fb6f6662", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#ad0660fb4aaefc64a194103d73c6697a7", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#abdf27dd352721543df44c2b861adf741", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#a5aba194d7cac254ac39f02c777eb0115", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop.html#ad64aadefa5e7eefe49d2e8a944b87342", null ]
];