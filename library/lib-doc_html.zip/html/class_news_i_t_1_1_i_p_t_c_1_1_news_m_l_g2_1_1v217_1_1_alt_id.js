var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id =
[
    [ "AltId", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#acd2e2e8fe0d0953ed43bff10a3a8331a", null ],
    [ "AltId", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a0921e8e7a36d5f4048dccde82b350c4e", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a259c829a6c70742e6be3ae7f83e3b362", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#ac6711259a4a83168b09ed192b1b466e0", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a597ef6eef038420172d00a703370be48", null ],
    [ "environment", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a677d657365493e1190cf548f7e5fc6fb", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a09084a92fcd3caca6fa032638d0a23c7", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a20def5ae84c2f87bfde1be6e13bb7cea", null ],
    [ "idformat", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#abe2879081ef265eef4f8fe36b2175699", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a7d8cb14e61a3967cf286f3d90cea67e0", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#ab9e2e3d4fc35771eed738fe33eb848ab", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a29fd383e0ccbdf71c2a3d1c1e9e39a99", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a51f2ad0850a557c9194510141c942d7e", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a056b26a54f2afe0f094404b8ab090d70", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#af29c4b2a2dd25fae4e2e907d83474ed4", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a6ec797447166d19c0d7a14a72f7a2fcd", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#acbc99fba8f1f1d3a1b5b79de6e1c5586", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a4c043c43342d23ba0b20a6a851682482", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a6eb3a196440799b71127d5b0fa80d1e2", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_id.html#a7e43aba95052f9d8739dfd4ddca165ee", null ]
];