var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details =
[
    [ "GeoAreaDetails", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#a9fe58a70744533b8b5f6d99ec7061954", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#aae028bcdb8cde4cb6cc916a5638854d0", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#a90dd3ee48d3de7c7ad19e990713f8617", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#a64ceb45e728452cad2d9bea86138f054", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#a1861e7a5f466750a3ec47143d286994d", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#af4e13603b2ab4181d9892d39726b6131", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#a440546475df315775c1c2504ca6cc55f", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#a93c6cf720d35fbba1dd1ff230a0fb9ba", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#a30a22fe85ba0c78ae985d203ea203815", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#a17f64ac289f0070c8363019a46be4464", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#afcd4b62bb8f8e12d3c6fe2b9506fdb82", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#a32a2e4e9400a6668bb8970bf2b1bcb2a", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_geo_area_details.html#ad573571f647e2d4530fd65d35ee74690", null ]
];