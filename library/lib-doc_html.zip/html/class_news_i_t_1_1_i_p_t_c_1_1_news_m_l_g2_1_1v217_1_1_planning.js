var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning =
[
    [ "Planning", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a288f3d78508a8bf480933264b0153605", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#aa8d72fbbf6d3a84f93cd408c39a8782e", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#ab9a49596351cdbb3c6da9971b32cd46a", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a8887ad83b6b47969c0a7ad4a56b907d9", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a774f1cd7426aa87673756d7dec8a2a88", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a401506a311e8f21b5be9e84f5bba6660", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a0af658bd0bb04207008569c6c58245bd", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a3787fa8ed945c88d095ea5802f5f1c36", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a63cd576e45555e2d12909efa47d4def1", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a18db091c609c8cfbbc02156fcafd423e", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a5951c445fea2f727e6ee4100359bd8f9", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#ad3f8ad352db2a833455f3ce908800c4c", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning.html#a4e45106b30993a0617b68085de9832a6", null ]
];