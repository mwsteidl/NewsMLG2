var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage =
[
    [ "NewsCoverage", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#ac76335456b93493cb75b8b3c9c9e60b1", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#a2746611ba73b87be8635621fb8dde421", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#a6ed3197ee79975e7b96916d207417744", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#ae1e7f443a351ee0b222ea960f34ddc07", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#a61f8ba06261274b48261ce24450cb240", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#ace33df21524ab6112b2f5a5eec5a3171", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#af66a8e536ad628726760801f257fe040", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#ae7d1425f650ac5c91ae7ec9eb22c6597", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#a2512cfec2b2a27731269ac5767bfe710", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#aa4c54e7d42e7d9d0c3063c8e5daff4df", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#a2974cd538a49c3853e729334dbad8303", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#a3aee8083212d815cee65f5f2579b248c", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#a932d5f64b7b73a0c03ad4da363c433ae", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage.html#a34f5f0cae38331e5bb590db5aa03811b", null ]
];