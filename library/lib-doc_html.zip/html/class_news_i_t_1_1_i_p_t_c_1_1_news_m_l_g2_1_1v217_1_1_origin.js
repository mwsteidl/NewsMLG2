var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin =
[
    [ "Origin", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a27415ef131ea79086797bfc97f87cf54", null ],
    [ "Origin", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#ab8497474002449167cddfcf74ab5ea94", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a09d5b4076498559e166b8363c6b3ab4b", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#aef44e1b103ed7277ba0ecc0f895b405a", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#aeaa7c36dd0901f6095a4b1dbae2fbf0e", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a53f860f9748f6ae5f0a54bd23c2500f2", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a85a7da5c13a8931b2afd5df63b315810", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#ac5e360680582158f62c80f0fa7b72dd3", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a8c8c0964a813c0a2c99d189c14012cd2", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a1478742e0fd8ae9c5488d28b9682a693", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a6982dc055787c18e38cdd722acfb265e", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a5c5abd1a0d86a8685b9691b567f348c1", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a0fbe249d41d35cb8079415e8c501c349", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a763303882eaf92a2e30d9c6a7d28d2e1", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a1e16c1467c6a203afde6cfc9195b9c77", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a8e00fe4ba4646523878b34e5d719cbbc", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a4c6601559607699ed06f6598429e29a1", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a0ed2c68f776fea7f89d336161c65116f", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#ae1b6a43086e68f3fc133a786657e4290", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_origin.html#a26921e754722c0cd707793f13737c909", null ]
];