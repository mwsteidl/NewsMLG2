var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag =
[
    [ "Bag", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#a4762c401b17381990e10d2569bc44cfb", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#a05f4487a6efba50a2da8344e3d21ddb3", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#a18c4794c0ca835f239b8e67de498460c", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#ade89230f47dace01773e80eb76759b76", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#a721ac4205a1c9914fc940771eb462bec", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#a8f74200530216af87aa544456ca3b53f", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#aa059b81daa7ee2ce9ef63c598fb5a7cd", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#aa0b867dd137a05709bd1f41e6a72dc08", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#a87a53a6141cc418a23f12227b7fb092d", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#a6a5d55797b58de9c63fb52f8c942b8cc", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#ab7e0ae0a36c4204e8b474c4270669b86", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#adc22dfe42286f686d87b835c0c68998a", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#a9f622c124ae625b0411b747e44dc8a88", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#a355707172b0d49d7df6f11458b5bd026", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bag.html#ac4ace96c4cefcafb422f9566dc4a6944", null ]
];