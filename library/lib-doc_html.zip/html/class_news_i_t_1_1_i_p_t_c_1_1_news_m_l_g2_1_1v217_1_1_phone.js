var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone =
[
    [ "Phone", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a4451bdfaeedf3a4fcb80ca55d063f68c", null ],
    [ "Phone", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a78018d4595517a65c3107aac6f039f8e", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#aff15c8607b40397e92e8bdc1b2620ae7", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#af5bf4dd28770595ce482c1c68c618d83", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#acd92fe2315620fb237a2910595b1a0ae", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#ac969b26872b845cb1c24b1a91892b5f4", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#ae57895ac388a7f131e21f1872f8fe88e", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a498399f6b5fc22cc50943ed6a5f84765", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a4e53c6e13b27827730eb5b557f97550c", null ],
    [ "tech", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a11d6cc462a28452e5b064f3ed456f742", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#adee7b033dc9ddc6aedd282a534e9f547", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a586e37fcc4dbb2415174eaa33cb0d0db", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a5a4f82c78b332fe897410fa50a0b3bd6", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a6835df54511ff512671114447ee1edff", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a3671fc0ad63109b8719e68a20df4e1da", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a68cd794884b489c5b50bd8f86e6f4eae", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_phone.html#a2a4e0d3b8ef348b8c98c8f2e26e34b69", null ]
];