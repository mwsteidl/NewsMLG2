var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created =
[
    [ "Created", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a409d2c20ea08a0eac783122d76f7126e", null ],
    [ "Created", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a0a196875050bc1b33a948e5f92e17350", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a518997857d5e119c5a6f2f0c826ae40b", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a298bd1a3f9ae0e5288b1e735df19e1db", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a1d0387cf29280b1acf3c5e3310b31e61", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a2ab56b967285e1c589a84e1707c1b5af", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a58cf16a001cef793edb8ff69e0c30d42", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#ad8d63b3b291ba095e551f322d75e034e", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#abe2d2cd7bf81fe2eaf35908ed169273f", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#ab47aa98f80b7c866bb910a7e7dbb0690", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a4284f5aa031edb819aa5130770c0e87f", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#af75828a067755c6d498a47a212a44d46", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a1ad06597153123e4892e99232bceefac", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#ac66307b26226b38af52357ba246e0eeb", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_created.html#a62dfd030430e0970c7adb5a5531c9907", null ]
];