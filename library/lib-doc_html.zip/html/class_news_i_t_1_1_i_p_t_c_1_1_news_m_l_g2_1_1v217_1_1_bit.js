var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit =
[
    [ "Bit", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#af290fbd4a46b11bb665c862a0f6439b8", null ],
    [ "confidence", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#adb6b18c73d041a24fd72d82375d0194d", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#addee350305bc22ea413d3a770a3f71ab", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#abc299ac5f4bc80e678825c86608ff5c5", null ],
    [ "derivedfrom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a15d62f59532a94c84344effe909c92f1", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a4d91aef5794188d5015eb1ce8ba95602", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#aa0bbee77e9a1e8e282c955b914a5635f", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a91e622e44f7ca5c5c88445fc83d22646", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a9c8d8b882d278af06107026277931234", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a2b207608a7aefa90227f4ac6df343a27", null ],
    [ "relevance", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a9cf90314ee3512aae5d7d94885c17092", null ],
    [ "significance", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#aba3858e1ed65bcec5bf4acf2a575419e", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a12f7b6a6b4fd78915cf03d10d8e1e775", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#ab87f00dd76d848460baba78043c4cee8", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#aa9ef66eda4d4a468aa254cab6f45b3bb", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a0472e20f68778027233ecc3d94668d69", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a55874c3bcd39738bc35301c3b95a3269", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a67809b1d573164866178a9dffbe66fc3", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a1a7d870b6b1518dee60d553ef57840b5", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_bit.html#a871e8056bbbcc50dc5472f44a07b55ef", null ]
];