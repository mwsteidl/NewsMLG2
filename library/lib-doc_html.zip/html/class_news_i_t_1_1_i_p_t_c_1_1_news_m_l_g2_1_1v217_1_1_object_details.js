var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details =
[
    [ "ObjectDetails", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a12874077165045d22dfc4d8c07559ded", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a42c33cc23f1023fa12a61ccd3bcbc7b5", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#af306b33ab62c6f6fdde6af1aa61b41e9", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a1164ce02018ad972f538f308e8e9a9ac", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a078eb4bf62e6fc6bd21c8bd62414100a", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#afa75927dde725132097153d9501bd51f", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a1973a973d45d84453737500934217232", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a488aaec4e9ca6ab67c280da4f0a41c46", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a80abe3cc1b43c561c52c29ed30edca1c", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a596f0b448acd94fd9a8c4955c24642b2", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a3ec13e23a93c4ff6bd08a9fd441372ea", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#ab84056fed6011abec4a3f5b3d6cb2e58", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_object_details.html#a2ac7353945eddfbe7258775964386f68", null ]
];