var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser =
[
    [ "Organiser", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#aa816d3c0f8e4d6d83d8cc1b50105ec7b", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a5f36839fdf207939d20926352d255413", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a134f0295b68782c77388b84c371a727d", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a5cdcc06b41f32b3cdfb4663ad51b9c12", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#abe3bd110601b94f1015750ffca645022", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a96e74cc79a979f762be53e2e865854cd", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a88c862130cb328d7ad4b89a53f8fe17c", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#af8faeaf89e56dffedd4837c9d17210bf", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#ac10ec3c2690d85f85a491ce50d57f605", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a09e6006f28ae07339833e57d4d33352c", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a60b781d06b4b463fc4ee5ecb8bdadeb1", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a7d32d1cc51324d93617ab629a99371d4", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#ae743145b8cee5f46ee020cddeaa746bc", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a96dbdbb8eaa2dcd906efc3f83ee50225", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a0010f1b8cc3c36dad0ac24f5a320b4ca", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#ae4e36ea213fe25944e188441cdcedb69", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a34dd327d2961ff8723fe6b8fc2d8f801", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#a03ce2fa852f184be8991d8b80877e76f", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#ae0ae68ff0643ef227d7c836982cd6216", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organiser.html#abd32ddedf2e5480cb5e3d08590ab2489", null ]
];