var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born =
[
    [ "Born", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#a68356254231b8b31717673cd73205c36", null ],
    [ "Born", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#af49fde49156b1183878f2ac4f463dad4", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#a7535c98fbff24e768dc2c2eff232a5f9", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#a24bf58bf31b0e5b96fc2d88216bedd1d", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#a1e16fbc02a1a8e76e2a97b6cc86101ba", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#a42fe53c08c4306da66dffb559545c95d", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#a30fba4288c39f0af3684cd4185dc8f53", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#a08acb5590de3d341f93b2bef091e980f", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#a10dcdbe89d18c385e418731e8633f63a", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#addcc37745848b1ff3a79ca16385ffa55", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#adec5722aac7fbf6c9cba751cab9809f8", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#ac72d617f88ede3ce56c23df149d352dc", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#a1fca915d5f1b749f744b308e643cf600", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#ac2e8f2765ec2ee76afffd9613b579026", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_born.html#ad9aa73e9f1df784fe7a21ff4dd5f0519", null ]
];