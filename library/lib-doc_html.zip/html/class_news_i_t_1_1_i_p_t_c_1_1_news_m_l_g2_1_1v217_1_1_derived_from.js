var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from =
[
    [ "DerivedFrom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a08d459c930d8232daedfc87094f4bfe2", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a356dfb97020a20985fc1fc1fa2e4e4a3", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a6072af4df87dea1e20c5692ca4e368a9", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a0419d1ea53fc223782d3e86fe3ddd567", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#acbb02cec2ae4255b2dff279634bbf003", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#ac19c0199de13bbe6615b6998210cd94c", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a6cf1a0ccb54acb7a7a696e275ded8881", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a0b06d8ef477bf2cada8195082bfef812", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#ac2dbcead1841b49348de985e13863008", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a4ca42eb0bb750ff5885d7f87c18d2fbe", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#abcbacd7abf4f08f56ca7b2e2801df0d7", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#afd5a6a191ab70c7305f7544cc77e4428", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a4c4b38253bf2f8edda93ce32b0814608", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a0dbab8781eea9358fce174d2a971eb50", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#aff33984ecc3f8387f493183e2f5c79a0", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a39736ff703c0741711e4ace22288a419", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a72729f8abbad71c748520dabac2f8305", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a5104a0173322d0c827d5ce2af73cbefa", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_derived_from.html#a58eacaa34933e57856288511067b0f1c", null ]
];