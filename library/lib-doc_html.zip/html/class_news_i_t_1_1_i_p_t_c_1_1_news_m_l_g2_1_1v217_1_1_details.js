var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details =
[
    [ "Details", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#add790e3f43bf117025d680a4e2cbb7f7", null ],
    [ "Details", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#ab2cc87e539e9b233d8d7ee72cced803a", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a9954e0b3acc71410aa9e2a39b0d72256", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a4f7004932396e9ef5473d9c82e22d765", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#ae4736504c904ef0331a75cf9b7d83c02", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#abe7328c8cd7fec3a051bddb949821d2d", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a894d1deffc75ef3b9825578c65b8e18a", null ],
    [ "media", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a98ca327552f1b8173f9300ba036eb74a", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#aa63ff54c0618ac49bf0f77a9a1348739", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a8630193b0c79b1bafec2b7242984b356", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a202abbfad2d0703bcc4d4f534149303e", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a6f6e7db7a903d3fae8f3fe5de949d7f8", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#acf8123e22f87f410294533dac58db32e", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a759719bc7277099198053ba32dd48e2f", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#ad6141df0c36ec0c61029fe7bf6953896", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a730c3b7ae6930ac86e81aacb54afb71e", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#aabc22a6921614c3a58727c91991521fa", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a94491cc9314b9bfa476b96eeeee4b75e", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_details.html#a5ea92c4af6975bb67f5a136dcd8a93f8", null ]
];