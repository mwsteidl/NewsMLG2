var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created =
[
    [ "FirstCreated", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#a3716dc9b50d94a5ba1342b0a21c381c9", null ],
    [ "FirstCreated", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#a83e54b58abc7147c990ca04b3f630b5a", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#ad7514c6f5b8ed16d3869c5f9515d7c1d", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#a57705df6a9c2ee722101f277b58194a8", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#a313f13c5cf4075414f328719e060ab1b", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#a3ec00a8949b7ec4143f1d67da369dc42", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#a62628aea19ae9508da5af60d3cc9e680", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#ab84fa81415a5fcd099b597b1c89d59cc", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#a05a5f1956816d238c3b5f34ac20f8a33", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#aada14af02d2a22ea9e1135ec39489e6e", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#ae8f51d794725a24642434272a9405877", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#a7de36c6c6e42d2f7cb244617beaa8971", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#a006e107abe49bc3d942f1c3b18cadea0", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#aaef449fc1f1ea8b780a029aa605591ad", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_first_created.html#ad4ee65cb4c0f4650bdfdbf974fae40ed", null ]
];