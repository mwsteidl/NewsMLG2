var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon =
[
    [ "Polygon", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#ae1ab0b8a152830383e1521a2d7ee0928", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#af7b047ffa5e1b3637c2462aca7bc925a", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#af4aac6c20ac810b2ad63a893583a734d", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#ab47f435044ec80d7fafafdaf392ad713", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#a8f6aa2768b2d91f2e2665c9daf47e6a0", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#a84916932b3ec1b516f2ca64fca2df3de", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#a6c7946af4635e42b8384e40efd3e63ac", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#a398b6485f45675fedb89785f26364b45", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#a3bb5793000ba09e4f9d4908927458344", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#a58c788c542da6051af49d4fe4fb5c2da", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#acb1e4070922f39de28a533f6e0982e76", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#a43700ed7d18ae2e429a5098b0ed042e7", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_polygon.html#a074486875b66f97aeb078551cab8f150", null ]
];