var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax =
[
    [ "Fax", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#a71545426f99b397b878c547d3c1cfb78", null ],
    [ "Fax", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#ae3e4d761e5f97aa61dc2080abf1a5c6c", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#a3c65342ab7abbe5b2848e60c295451a3", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#a94ab4ff4ab71d0581c0a40cd1eb43a1e", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#a8244948315a8c0c9432836827340a1d4", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#a1f0b93bb0167a766586697646625753a", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#add76b24047b3056480b1dd34d8827eee", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#a375ccd69336eda21371d7fc4ce571baf", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#aeac2199517ed1c8dddb7fa835b7cec55", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#a0566dce3039377d3191853911acd6339", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#a06e180bde6a6a2cde05b370ecc0ab97f", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#a897e415d234cd1a9e0a202cf37f29314", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#aa4b2ec3d6d786a8e0d79587e593f9e61", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#ae8996ae1ad18a90796287c1252e7a96d", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#ac358f6268305162f28f65841c6d4407c", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_fax.html#ad331c4dc4baeeb498bc5b3f091481f44", null ]
];