var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set =
[
    [ "ContentSet", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#ae56ac3c3530ea0e44c7451dd16ef7dbb", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#ae27d8b2269d47d56e89dd301860b2a7e", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#a89c9cc1442e0a5ee13f1c6c6f17b6b6a", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#afca50b99103066e1ae4930d2257a9d59", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#a41ba2d09f6e41059f4ab9b66aebef60d", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#a2d119b0d3098801765ff234b4b768916", null ],
    [ "original", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#af0e0fddbb4c7f4a58c5b4b94f6db627b", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#a081f854baf4cc4c80397e127295096e5", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#ab13d49eb8c4b949d662f729d3a6bbca2", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#ace1f4c2bc6ca7ce6dc11d4570337fd6e", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#ad14847fc97f3b607772615e7cd753c24", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#a64132197f2b1985bf93aa4bae5f63b0b", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#ab5b06d5d84ccc9a56abc7b9051bbd119", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_content_set.html#a6b74f7a394bca244dc0661d3cec362fc", null ]
];