var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item =
[
    [ "PlanningItem", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#ab60b33e8d7c8ecad142d150b045cac99", null ],
    [ "conformance", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#a94bd137f1914eadb6c3b5fa351bbd20a", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#a204c56b179b119ffba097df549c9b972", null ],
    [ "guid", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#a321ab236802038043333ee99ef11670c", null ],
    [ "standard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#ab5877df856808aedd62289d741e158c8", null ],
    [ "standardversion", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#a4cb8d2c0d743052a3c01b14e4cd16da0", null ],
    [ "version", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#a69b5bf7528ec8b05125fcc354c124fb1", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#ab13fdd6fa675a7f06909739b2bc69a89", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#ab83b0c17337da7a857532b121cf54701", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#a3cb85079d06862f10d894a72872c26d2", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#ac7b77657c708a3f98eeb30b1cd347df5", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#ac7adae456e5c62ac30bb694118362078", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item.html#afad668b881a051430c31347e239d85ee", null ]
];