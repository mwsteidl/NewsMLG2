var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status =
[
    [ "AccessStatus", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#a4f028b9002a691538b20d60da5a72525", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#ac3853f4d89c0926498568c4731e6c613", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#a8dc2c4bb4239b68c6b97abf13beb3218", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#ae8e07bbe1a0258996cce0f5dd746b64d", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#a4c61d1bfdca2409f22de56d19a544f95", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#adbdb26b7551e91ce751e790ba129a657", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#afdad1467ab701c0e7af7e8f707cf3f05", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#a6baf756681cd28c04a548e085387cdfb", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#a510bfa29914cbe345e3ff3a99cba0cb2", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#a55da143419e3b85d5f69a264fd658bc9", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#aa379173d1642f6e179c79f9a382a8e9a", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#ad26e1d40aede5444386272caa0406a64", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#a3ce5e75ff24c9996222c6238549f1bc3", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#a3b9588bf3755ceb0cc6e944e1e1ac6ab", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#ab6c06e1ea674e6f1ec88d5ec1bf65a52", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#af00a4328c58d7ca08564b17731983172", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_access_status.html#a0cfa4008df4fb8c18e5d2158bc208a71", null ]
];