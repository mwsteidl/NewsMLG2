var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority =
[
    [ "Priority", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a72d84fdf0c84910c132fe1d72089e5e2", null ],
    [ "Priority", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#aaea4095f891840d97a626b6a92d329a7", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#afb766c9b0b4ae2c1c74fb731f144ef48", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a52a57fb17cd948f4bb08812cb4f00ec9", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a74a513668064f3767fd96f0d8d68fd65", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#ac3728bdd1515d83fd8a06d359ad9b3a8", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a381562c00f8b7fea96af282094263c72", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#ade95c755d8e329c4c4705e0483ceb7fb", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a5e9c0fb92eae39faa1615b428c38518c", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a89ef4e3558fadae81bf5646a05cd682f", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a07304f2e8cf8f18bced94b89fbc05808", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a2ecc0c29d251cacf0c6da8ff954863e0", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a09a0f70a576b7151933e7bca73d78f55", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#a419b15cc57b4334abcdffbf2757df03c", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_priority.html#aa1191d7a77f583eccc74a4fe53a6dd5c", null ]
];