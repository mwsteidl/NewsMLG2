var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source =
[
    [ "InfoSource", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a62dc84216e92d8f06e3bd5ebc10647a8", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a7a657982240b900aa4c4ef497445f404", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a3f48a26b9c7aee9fe94d09e81705910d", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a3b9c83cb542191d2a2057838bb224a1b", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a5870128981c4c25a5e842ed43898a7e8", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a73e7491352656e2e7620651b8be3789c", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#afa49a03b10fb78ce71b53aa2cf0970d5", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#accb3179eb1e5ad3f67beb124c3903f37", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a111e7acd33c7de328167650da24feb18", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#af20b097fc679c52193b4ad0922b53550", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a20b7ca76b786776260575dbb52faae4f", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#ad7d2c48e0f133a2d3257530b87ab2219", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#ae7edd77849e2e4f597eb3b67089e8edc", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a7fae99de46dd7ee96cec7f4c11cb9526", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a5950ba16ac7cf2c5bf046799078c4a4e", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a44b9ee7e4b4e3d14bd92e66d83c731ff", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a6c183a6795f9201c0b3d2ad90e63ff1d", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#ad7a9142c537c14e67bdedba0ec04399e", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#a7f233c129b3224cc7ae69a8c0e4e60b6", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_info_source.html#acbca410b9f5e0a4e92b482e30bfa56cd", null ]
];