var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept =
[
    [ "Concept", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#a3027decaad6ceab33e54d83d902223c8", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#ab3a5f55729902ba6885d47f2d556a20f", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#a684ed70d4c66c76b63878a17eb71d4cd", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#ac4e764ae0c064bb2558ecd406ebdcb54", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#a89479aeac8209207c82164bb1320e8fe", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#adfc8bfe2a33593bb8bbb38f870fe623f", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#a01ea780b026841a8f2ad719171b4d2a7", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#ab695137d2a86b048c4db3ac039a4b0b8", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#a2cc070f45727d69e6bbd71c4fe998f39", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#abbeebb68a935b0e3e8ff1258dad9026a", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#addfbc354a7ecf9910f604dd0cc8203cf", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#a2099d09c8674f25511d852494c328827", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#ad1aa17dc8417af789c958dec689ddb58", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#ac95047efd5047607c03883ef4aa0b020", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept.html#a0ffea3d4ecca34cdf1c6797b129e9cb8", null ]
];