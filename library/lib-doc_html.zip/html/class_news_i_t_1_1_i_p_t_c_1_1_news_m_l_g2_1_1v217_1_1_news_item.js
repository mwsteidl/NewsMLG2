var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item =
[
    [ "NewsItem", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#a22b09c0b1bfea59b86268060f8a09935", null ],
    [ "conformance", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#a1f56b242b58f422a67cd75646b4fe6f5", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#a6aa0a25e6994e32f86e345a2c4edda87", null ],
    [ "guid", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#aece270a69ca5d0056efa1812d23b4945", null ],
    [ "standard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#aec9df3c7779ac5ec911a3ae90fb31b68", null ],
    [ "standardversion", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#a4e350287c01a942eb540c8117847b361", null ],
    [ "version", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#a7f08a417bfe72259178a20bacf6e10fb", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#a09402a601d703251088b6b6e8215e922", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#a7fcced0baeef24a4c5d4092d7537aaaa", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#a14c0153982003429bc82426c9cf4a378", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#ac68a07c9657eb700f2ba94a7c6903288", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#ae4e3f86ab0cb2b0f1c23f5a58f6b75d1", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_item.html#aa388488aabc3fac8dc728b5c533a8456", null ]
];