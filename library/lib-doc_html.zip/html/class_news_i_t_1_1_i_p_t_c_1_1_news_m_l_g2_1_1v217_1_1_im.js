var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im =
[
    [ "Im", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#aa88d601bdba97e46f3b6077ba5e1acfa", null ],
    [ "Im", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#a05b3a8c327dad656fb90b9bff4a83e1c", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#abb620db4d55e4bbca9da5fa83258d784", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#a83810e3ccd09fcba8d28757aea4444f0", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#ae2326d09afab4ca0fcd224229f62c799", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#ab50dbc312c73568d05028c8765b67254", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#aa4dd36a9af5add4947bef7cd7354d792", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#afab85d4a5e13285df4eeefa989a33cde", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#afa47f9fede6289c65fbbbaab4d46f0f9", null ],
    [ "tech", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#ae01e5ff63d84e605e730da9cfae2ba8f", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#a97298ffafabbff357fa2536c8d68f211", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#aaa22d888fd1ea6772713676498667351", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#af239189c909ee866dec7deb03386cb31", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#a03db79d36453361948befa74ca85ef03", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#aefcae74a5268b65a9b84b6d19d0fa4b6", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#ac5ee308829d7dc49d47e67b47c2cb3d1", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_im.html#aecbf15feb5117baab443b3a1f46555d5", null ]
];