var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog =
[
    [ "Catalog", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a2c418e55e20330f40d3f26f32210e5c8", null ],
    [ "additionalInfo", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a5b1c542e239643d654df495620907f29", null ],
    [ "authority", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a55541ae1fff575e09aa1b74dbd65adf7", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#adece6b66e3bc3b42ca3abcb06256fbf0", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#ae8cf72fa0823b5418b2a02cdf6dc4b2d", null ],
    [ "guid", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a638cf4447706a2b366a104b4547712da", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#adf3413891c84a13035df85eaf648a5c0", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a7372f4c4ea061e1cb76974f0a67a4392", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#adca2b04ef7cddd0cdbac27dd51ef9745", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a771a131ed3ed354d17effe52c2e9d742", null ],
    [ "url", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#aa598fa3a75451b4cd130eee996f9ee6f", null ],
    [ "version", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a62d46762d12c4c550532d0c59fa1307e", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a09eef3b85677d33d867cd5e7c109161a", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#aac21b355239e66dee550a8b1b402dacd", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a7d0f1e1f87a99ce1170753da1b17d72d", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a1cd3a070e39ba786c4af0a32952e280b", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a7c2d3ccd708a0d9a49952860afd83745", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog.html#a6197ca55cec6b6d24ff84f6826b550d3", null ]
];