var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header =
[
    [ "Header", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#a6baaad88e23e6414b0c09f7ee60ca112", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#a0edd20035c9e1aa734e54e2734f7d659", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#a2a5b253339c37384980c254cee8084a9", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#ab507e78751e51fdb4d0ce088f40ddf3e", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#a1f1bed8a3a91614082a4346b6d1e1733", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#a9a63f5f473533f67959b4de3b33017d0", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#aec9923be5e8532ac419963bd3a9ee761", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#a9830a6ebfc6a052265facce15de5348b", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#aec3a17036e4f678e78c5cf56125a3d8a", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#ab95972ab13b1d4e14cba95acc62ac0a6", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#a119f985e96b8f8ae85d3cefb35710b8e", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#a0d15c37da6add4c2a5ee0e513f6392ef", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_header.html#ac12d7066db12b18ecb2613f0cf7be98f", null ]
];