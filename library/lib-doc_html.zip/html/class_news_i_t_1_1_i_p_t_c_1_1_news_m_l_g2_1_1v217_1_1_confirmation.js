var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation =
[
    [ "Confirmation", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a2c7a4ca594426681fc600d882cc5d4f4", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a813c8823ca384b7789852efb0fa42d66", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a411c6684ef0545a2851c378ff4337c5b", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a791d1e1aa4535f6c76dfd38d727d96ba", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a979068738b7f869862319f6fd6ceab0f", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a3a41a3b10ada727db91b4cdb8b164c9f", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a76128c90f9ff2a4d7f474c12044fd20c", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a51bddaa856abc11e0a715e7d5fdc0e96", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#afe8af857cd35e8a713a1018b6ec2c6c6", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#aa465cee527d9691f63db6cdaad6b4dec", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#adc0869d31104e8f3f5e3711ef7ffe167", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a5f6c5e69ea6e178ef8fd061d8e78d106", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a94fc7c3c05946fda197f552c3417062b", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#a69e7cc0196d3329b99ec97984d52f420", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_confirmation.html#add8b6b0fb2ec19d780d060b2c75363b8", null ]
];