var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item_pwr_xml =
[
    [ "PackageItemPwrXml", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item_pwr_xml.html#acc2d8f945e0ded0fb82c27f075aae34e", null ],
    [ "AddGroupSet", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item_pwr_xml.html#abb4ba5be9ba40cd3273a506dec83a66c", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item_pwr_xml.html#a371fa13a6ab997be51285b93457c80e4", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item_pwr_xml.html#a2b32231ed56a700ec20d1ac216bd326e", null ],
    [ "NameSeqPkiGroup", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item_pwr_xml.html#af90fa06ae8720ca772eff2b05caa8dab", null ],
    [ "NameSeqPkiRoot", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item_pwr_xml.html#ac67b997cf01fe4947855030cdcd36592", null ],
    [ "NewIdSequence", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item_pwr_xml.html#a892cd2ff6131c772b77dbb8e5591b24a", null ]
];