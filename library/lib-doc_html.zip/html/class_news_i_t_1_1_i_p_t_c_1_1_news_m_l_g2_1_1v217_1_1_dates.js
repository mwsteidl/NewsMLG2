var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates =
[
    [ "Dates", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a1345f1e3900aab8f515e07b6422a953f", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a1bc17ccf8dae2f74091b7bf515569373", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a88bd2b1d189e608ef2f7e061328df255", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a3c80821588c81b2f38e3e81bf6c10e3d", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a06064882b6e94dc6527e29edee412ee8", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a435c61db8ab7aa1982004d47e062aacf", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a211ff6f2e69189da0252ff61a8cb5bfa", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a11bac438b97a23d131260c5666ae5647", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a79958686b750a4ae5373773c6dd606a7", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a545688137a835a80065310f6e2a7beeb", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a47d5242f5989cfb098a0a342a411a960", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#a3b4b02a30cbb4d943701d47d127b6d12", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_dates.html#abdf04c0c883adafc42175d29ec7f941b", null ]
];