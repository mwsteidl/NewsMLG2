var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event =
[
    [ "Event", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#afdbbb7354cb0e2f9c87ac8675ce56a9c", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#ad43e2c293b3c50e6e3f15e2e21fa67d3", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#af829330a69e3dc838221f4ab76fa0d33", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#a939e0c43feeb96067635a532fae36af1", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#affc5db60ba4e82947fbaf2271d68ee07", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#a297b94e3a832b519103f6dbefb387e00", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#a0c826e93173a49f9a3929b20b33a1d44", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#a60da4929936eca6a9ccf347d06a76c87", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#acacc0e467b681176ce58e4e649f88105", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#a3f3004fd885b87343d8209c2250e7684", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#aaf6806b691ec5ac40045b6ec1d0d1058", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#a4de758ce8c800366f9364e199298e2c2", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_event.html#aebfff5cfea42489e361c4865b61012de", null ]
];