var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref =
[
    [ "GroupRef", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#a9fe48e12363dc4e3c6e14225eec74ea3", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#a7c60286b70c45185931576a6d6c72889", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#a8895fceb412a24fa7b4e1ea96dfcbeb8", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#aea56352c5fb7c99a9aecb8234b96460b", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#a813255585496ab6f2a5f6805ebfd0d2e", null ],
    [ "idref", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#aba096988be41878bce7e9cb5b9b250e4", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#aa1997cc49921bdac94c16ec89a3cda65", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#ab6247fe08f4a7550948b89c00b30e87d", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#a4c4de4cba381a99fe5fdbba3af47f0f4", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#aa62ad2990a4597cfb031de8aba30090d", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#a3a9a37e50d1e67178129642d542e2ce7", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#a5d433159b58aebd40dd401b0d5ba0d2c", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#a9435ca59e52c46de177c1d74899a6527", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group_ref.html#a73f280052a89d47f9d61904d839a0dea", null ]
];