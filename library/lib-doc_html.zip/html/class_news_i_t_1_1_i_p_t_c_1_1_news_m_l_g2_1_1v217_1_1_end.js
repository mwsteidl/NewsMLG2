var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end =
[
    [ "End", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#ab8deb958876b6f26347ad0e2d5f5a535", null ],
    [ "End", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#af98df5b574dda7191d7ef0ece6ff91fc", null ],
    [ "approxend", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a69257159e8771667faf00b666a0eff94", null ],
    [ "approxstart", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#abcc9ecd428cc08cfb61d4eb28555be0b", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a537721df22da2c83b378f157a3f2335c", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#aa0cb7369d5579ed0691ef5c35ddadf03", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a19ac600f9e5004834988d63e0493bcb0", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#ae1f60cd0cb5cb48db2bccfa596b4766a", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a859d096bb1fa4bda1d6806b4536ce65a", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a84c4daf0152b34590ff666bba08adfca", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a6dfbf41cae1700eaedeaf7485d6e7861", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a415439d03d7702fba35df8f585328b47", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a537fc072f1ed3f01664738da757e6089", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#af7de4cb969ee56adebef83d724435f4f", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a04db330a85f9a847c53a7b722e8b6eb8", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#abb0504685f7357a96e8f298d576eb729", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_end.html#a908acbb33248f018f1e23eb13395f824", null ]
];