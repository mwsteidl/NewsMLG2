var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a =
[
    [ "A", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#af55ec02efbb7c1bc95119c7c654fc7ba", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a96de843c3c823edd42f8238fc6698dbd", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#ae78cbce239d6b394bc0962b4c0d15880", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#ab62082da921d8b9e46cb5a9fe79b378e", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a1937b850b200ff47ace02e11206d5ffd", null ],
    [ "href", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#ad328ada3a2172280abdc111aff454394", null ],
    [ "hreflang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a84f4425a42e3c547a6ea12adcaf20894", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a99b1334bd323f23530b773e6da0912a2", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#abed7b0ffa552288085a0021ea92313b9", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a71c9906303c7f4e544cb9703b17f3794", null ],
    [ "rel", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a3291bc657e8e4f9d7acfff0202ad20a2", null ],
    [ "rev", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a225361c4132b6e55a78079d46e97928e", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a7fdfcfeab9b8711e1d1aef19eb354116", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a3353f3c3d26df89c2fa261f904006679", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#af47ca2ffbed7d23d72b08f1c3d91ad3a", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a06740cb1ba453fcd0384fa8f720e6c6f", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#aca5f50e3dfbeeab9ecdf890fbbb84a92", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a30b06648a169829a58d6ea718d57538a", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#ab26e98ca8f3885d62d7a4271e64f4fa8", null ],
    [ "Yclass", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_a.html#a1efe2c0065757968e5a62108a7296bf0", null ]
];