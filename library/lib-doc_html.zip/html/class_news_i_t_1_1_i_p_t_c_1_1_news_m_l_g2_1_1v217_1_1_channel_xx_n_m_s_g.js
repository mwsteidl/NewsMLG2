var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g =
[
    [ "ChannelXxNMSG", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a4f293705c1bd63bde4aa5c9305c84433", null ],
    [ "ChannelXxNMSG", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#ac0c14e57271bdfa5b9c3ce33fd8cfb55", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a172e692c806fbb3a4d6b9504e1c94987", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a5b6ab85aa630d8019ba94d75a579afc2", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a27642a2fcaf21373ea64e42786264d59", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a5c4181621f7e8589cbd2c43708497f16", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#ab22fc6d7c923f26664617af99d828624", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a7f3040e23ec17915739e297b57c4b64e", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#ad24f14abca0f34b3a3caf2439997230d", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a06d329b2080ce23ee83e40ad1eed1a12", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#ae9d47564da810ed15e96bc13968148b0", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a1001ded9bbe7969918ff3d7d13c510e0", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a53f2e7dc20dfa453f78672aa28aca8ff", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#ab6aedde8fba5ff1c983e6246c70875f3", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#acf147cb2efc3c3379c8fed40e2450976", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a2ee1de6a4d1c299949697c135e84fba5", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a66ba1cde698404829febfa5531e5ddcf", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#ad5f7886ddf2ee774be33b32eb7106611", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a84488d8a16647ad02030f820edc3d65d", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_channel_xx_n_m_s_g.html#a535354a7e43f396abebc820b80bd4bd6", null ]
];