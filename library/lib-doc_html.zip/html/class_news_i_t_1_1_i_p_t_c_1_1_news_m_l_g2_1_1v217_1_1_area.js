var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area =
[
    [ "Area", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#aa0c96b1a3f18ca5290659568f6b5d713", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#aa9e39150f127fad2d4be997bd06c9d81", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a6323655e1784cebcf3fa86c3b6810d6d", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a5c707efba056a9b6946330b94e994aa7", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a390b2273206e5d1577d810b804885206", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a3f9f04351dc0308cb1acf4e09a28e9c4", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a402385a936beac51f805135f88c60335", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#ae98f2935b1409269f482b8f5637e19ee", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a7abe0d422a3599e935b4808584af0997", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a7ef55885960739e199c837483945b9fd", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#abaa5ad96caa6245981f5f67f7f7b8be6", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#afc49da628a80505b785a4e8da5f36cd7", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a825f2e2223b41986a3375a113f53fc53", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a196cc9a2845d89821d272fd7ce20d293", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a42ed7835bfd1b4abc86f0540d022e2df", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#ae3aee5048f63d91e70b4db798e8d6c10", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#ad5d27ad3e3eddaba3285466dc381c63c", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a9389b554457ae77ca0cfaa8460accbaa", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_area.html#a467b11ef3eb479916c166307e719e59a", null ]
];