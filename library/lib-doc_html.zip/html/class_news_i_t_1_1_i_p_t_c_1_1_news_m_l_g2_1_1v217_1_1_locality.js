var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality =
[
    [ "Locality", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#aa4fa6f6a906bfce4d4dfbfa1cf308bc8", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a2a38305f6cd017240d7d99ef33251bff", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a9c5b94df37dd61f365ebffe69adfddd3", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a95775a6672a1735ea0fbb296060a05f9", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a27b227d91438628dc58c228d81bbb575", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#ada75a25d18eac24114c927f271a86fdb", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#aba2a14fac3199b2f6caa1101eefc1f46", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a02e398d22dbef2587fc1f97c1a160529", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#ad30b7d50580f5444735b5301cfc7ddd9", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a6e2a1fbe881cfcc6b7091ba487b31d3d", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a7a27f803cd7e02d5db60162c0f4f1db8", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a3cfa4135f99fae7e99693725c924f4f6", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#ab8b62d7bf2e10b35d00d555fe1f8f927", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#afa4f2855cb717da2fb57af8297340d2e", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a8bb83107412259b8ad79ab9872532798", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#af986d3bb472870c3b79efb36fcf8c9cd", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#acf28332f908f5ab01b63b6b329821cb5", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#a1052b82264600035f9f57ac578e9cb5a", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_locality.html#afb1f03127918e4e16b330425fa7d1ef1", null ]
];