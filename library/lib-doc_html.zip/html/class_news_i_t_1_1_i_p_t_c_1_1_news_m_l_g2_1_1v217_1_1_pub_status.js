var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status =
[
    [ "PubStatus", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a09909de8846bf8b01cd5c667d5cc2959", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a1564ef9963568ea3b41fba550f0e96e6", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#abab4d471e32d84c62500a3e567a38b57", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a09ed1c7da6e6959fda60349ecb6d6937", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a8c16d283b8424e5ade437810317f71bc", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a9c4fbd6c941e2f06dac4cc2f8a03b254", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a6626f52791791153eb364eecae8edf23", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a423434c2854cfc41cf37624b6860034b", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#ac37ea97d391a49f7e81c857869edc90a", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a60c2d1fd6aae865525bae774c1a8f8a2", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#ae8bb0e16464398ef6db641497b13fe97", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a9197ee3b175d622126e7b94c6d1ff2fd", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#ada33a6d0d9eb3c1696395b8557f4de1f", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a171dd43fa8b5b969dc855991b9b38cfe", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a1690f2e9b7e7c06463ac4aefff9faeb3", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a6ceec87de34796a2e488c0bc9942e1fb", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_pub_status.html#a7fb7dc918698b4c36f9bf60be7031dd8", null ]
];