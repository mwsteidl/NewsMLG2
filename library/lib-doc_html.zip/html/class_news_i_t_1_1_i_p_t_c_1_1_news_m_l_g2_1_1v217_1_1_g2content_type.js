var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type =
[
    [ "G2contentType", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a5fbc42abfcb184bcc9f0fd5a2c262990", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#ac257d0b5e3cb346efd299ff9e5e2af6e", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#ac12cc01ac4d1e148d417ea89e8924368", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a3ae4e619991728e10d6136be23d6146c", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a35d85ef7f8de0f32a945135c12be0a99", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a212e3b16897a3b9cf0cb695bc5b24a26", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a88cae8f7bc2242cec214ee9aa96ba9e3", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#ae5811c14c8e15a5c973894e8b17dfa2e", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a892d861f72f18e25492e8af121c04e07", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a3ebfc2f43b6cc2df4598601912fb6364", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a16cf949b48f768919116b5ab401d4d72", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a28ac80aefde12f3afa1167060b892c7b", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_g2content_type.html#a398c2525c49e401bb2e0a581bf1f18f2", null ]
];