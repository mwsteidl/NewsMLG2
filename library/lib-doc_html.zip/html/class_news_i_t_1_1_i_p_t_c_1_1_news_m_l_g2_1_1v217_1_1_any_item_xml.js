var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml =
[
    [ "AnyItemXml", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#acc5fd9678caa511c4193e3180d5f494f", null ],
    [ "AddCatalogRef", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#aee6f62f3fbb1ee9f206abc68a2fdc91c", null ],
    [ "ScAddCMcontentCreated", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#a657a3990b4d613c3ccac871ea326ac3c", null ],
    [ "ScAddCMcontentModified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#a0a2caa233250c94aa1f547d926af33c3", null ],
    [ "ScAddCMdescription", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#abe0ab3f78498f87e7a794aeb133fc780", null ],
    [ "ScAddCMurgency", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#afa276804c524dfe8f62c7a4e61c2e509", null ],
    [ "ScAddContentMeta", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#a725243ef60a9850fe3c08c41025c8023", null ],
    [ "ScAddIMedNote", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#acc0c02842236d346da50937f48170b6a", null ],
    [ "ScAddIMfirstCreated", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#a4bdb1ef6ddf205e43a892383bd476d13", null ],
    [ "ScAddIMitemClass", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#a689c631c8593e9b1d3a78caa99571cfb", null ],
    [ "ScAddIMitemClass", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#a77c3c690d60c3879a6a5567c72e9e19b", null ],
    [ "ScAddIMversionCreated", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#ae8d07ad7f67ce2ae9fff026367b72db2", null ],
    [ "ScAddItemMeta", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#a6f7f3043ef50cdc22906e352139ed3b6", null ],
    [ "ScAddPartMeta", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#a52bd781cbd6f540ffd253c2df3a11b5d", null ],
    [ "ScAddPartMeta", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#ab1a8956b12888d272a4eb15587e3166b", null ],
    [ "ScAddPMcontentCreated", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#ab083d9ea85a2d564b0bf30a219bba1bd", null ],
    [ "ScAddPMcontentModified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#a07fa7a18923a3b37e930bd3e47cc4f5c", null ],
    [ "ScAddPMdescription", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#aa2eeb16b7d22c8c57ba3ac1fa1929bb8", null ],
    [ "SetGuidAndVersion", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#aa9e3558328af4ede7a9c477fe7bb86ec", null ],
    [ "SetRootXmlLang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_any_item_xml.html#af6cd271fc6327061a3125f140cc46a3a", null ]
];