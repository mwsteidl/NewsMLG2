var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group =
[
    [ "Group", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a17d4dde2e55721c65c470c44a217692f", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#ab1597706c6c2be4679d004e1e0308b9a", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a861b01ab08bd51733f50f2d767b8810b", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a1ad21c3dcdac7039de4f62d50fd366af", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a6fcc0170074706aefd0a0e58e922067b", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#aa172df0f976390fc5919e8e04a10b7ff", null ],
    [ "mode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a68caec426ac97b6ec0987479b2029c64", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a27c41aa5771d9b96c507ddbdeccfdf2b", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a511400944540630d0284abb8d72ec40b", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a158fe8772e18c1f31c32a8d31e8d64ca", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#ac6bfa4b62fad4fd1bf02afb337a11f9f", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a859656607484d801af91200b2939e00a", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a06b99e392eda763eca4bc5563fe9bc61", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#adfa80b37340edd9a1caa4b6e3df663ed", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a4d1bb685cad4527e000a7a08b1b231c2", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#ad9f056e724e06cf69ee5bd6b1759241d", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_group.html#a7bb3fc5b2aec53d5ee71d52f0d5fc949", null ]
];