var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status =
[
    [ "OccurStatus", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a1e8edda1a95ebac1741f7228d7e8795f", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a6c46ade750135687dadb17c93777011f", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a3e37ce24df70defc877d7ed978ffd861", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#affc18c41baf111f1e2367d20b0eafc42", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a2e933c6983077be1470bed6149fc7fa1", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#aae96de8bdf4840f97377196199d771aa", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#ac3999e174d49f79ce441aa4aa67060c7", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a2e3d44743b05380d520b392635a0a0a9", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a52b6256bc2baf3317507210fcfbdd25a", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#ac2d7fc8318569a53c182aa8e6c9e4f69", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a14a05791d43287114cbfbeac9e0a5713", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a8ebcfb3e679fbda904f4ad3a09d6a0f5", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#aace234fdc3d216e6ed834cb63973b2ca", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a76e068e67ea5c48569a70c631faa6950", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a851564d9a7227817bc5d46bc51f696ba", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a326b884eda76bcf30cf8c3f475f31c3e", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_occur_status.html#a7548ebcba7bb40eaff3bbbc5a2137b58", null ]
];