var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details =
[
    [ "OrganisationDetails", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#a0356fd6b41de0b7af40d8953ddf10d62", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#a29826a336017c191074b492a3bc59c0b", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#a669a178e58f08fffb090f9acf707b265", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#ad1d72a735df1d3b286f834ff52355a83", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#a2ef17bd6a6d31b4d3605fd20c217a40b", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#a1375b6dab24995cffd468cad0a17af42", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#a6806eb87e30f98142d7d8459b2bdc940", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#ab697c8e3166b9baf9e45dd02af6e38c0", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#a7c46d912b8c975992b2f847b0d5c634c", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#a5d4796ac32fe6ae2aadd0b918d16f18d", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#aaf6028a7d2a99735a80a99d718511323", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#ab8064d2e9d8fb382033773e4ecb4db9c", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_organisation_details.html#a045e19de929ce3dd9c610abdd954e3c9", null ]
];