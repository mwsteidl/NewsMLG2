var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history =
[
    [ "HopHistory", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a213057f72f304e771e36a37405d10e40", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a380d5b4c26092b770bec2bdbcfa2b329", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a8c54cc91616af637445178b711c0526a", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a8e19797e25d2a568db07c9f00e6f866e", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#afda4391fa03ff137197ec955423bb47e", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a86a3b41a1ddc419d846000f722e86a3b", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a53bef060559a69f04947cd28ab5a7f0e", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#acdfd480cda914366d1f3bdaa60e7235a", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a4c7d09e9d444ada8c9496be044605338", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#ac73626b588c06e40649434ec6e84cee6", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a224fa99a30b1e23d9305c3811dc337e7", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a12391894977f1fb936e85fcd3835001c", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_hop_history.html#a7619c16e85fe0344bffe038d42b94181", null ]
];