var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration =
[
    [ "Duration", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#ad90c050fbf0f369c6b070f459ff8b6ee", null ],
    [ "Duration", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#a40067ba7f7b08a67f558c4deb2eef8ce", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#a69e2075413867db9d94c1c44515686b1", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#a8ea5f790f60e50ee75ac2aedef9354f1", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#a7450e91f8fb80a997808ed2d99195bdd", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#a38616eac939d8a286e30baa027a4389a", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#a5a0403d9938e0e314e88c1874f82f321", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#a9c0189abaf0bbbad5bf5ef270db8a7ef", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#a0ebf22c784d530852dd16d4331dc30ee", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#af2f6a0f56a0516314e01d4f3b087b985", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#ad12acbb6b980898f602e24bd6729d313", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#aaaa04d82b77630d7aaa425ca15fc778c", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#adc1e9ee26693ef475c26a124506d82ef", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#ac3c2d1bf5d4791ad5db82bc43e463a3f", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_duration.html#a282336330acd6b3d00ae3d9297db4b8b", null ]
];