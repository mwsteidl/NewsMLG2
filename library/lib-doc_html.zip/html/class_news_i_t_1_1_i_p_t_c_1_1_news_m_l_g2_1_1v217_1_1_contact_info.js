var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info =
[
    [ "ContactInfo", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#ac92872b1df0f3be767cf1c236d989e7b", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#a34c7d9fbb7057685c5c6a2c1221d1a80", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#a92338245a4381d199e2c2db4fd5ce35d", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#a504faac940402e590f18cb4080d8f046", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#a145ddeb2e39218db9dc43d7dfea45bf4", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#a6323788b806665dd1f6f7b2b70c764e5", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#afaa3db7ba06535d22ce20d6dfa35ca4b", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#a075256c4349e666238ddb02be22826b0", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#adbe58b3a57f86f95de12632e9f0154ae", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#aa40f20fb4d1174080c4b4f4ef3959050", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#a85a925a9d68c7598db9f0de4e3614e51", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#aaff47f89af8598d0a42343271a541901", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#abe5caef8c5d3581b7d84ebfb8a0c104d", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_contact_info.html#ada039585f8847138a0a5b44a0b73329b", null ]
];