var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died =
[
    [ "Died", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#af13223ed6a898dcd2ebe6cdb04348157", null ],
    [ "Died", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#aacbcd6f8db8e5d4e64808042e83eed44", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#a4c05ae02eddea4422646da7f984fb54d", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#a43e5497722aafb73980b36d0d4f07a3d", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#a9aacdacfc33bba8366020d1e218e6f8f", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#ad03e37c74c90b810a969b5ef176f4e4b", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#a22190ed8a73959f522eab39d34d8b529", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#a3e544f7becccd9aca4d02d11187330c1", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#a5517e623f2df96a16526aa3394033601", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#a99a90026a970e32c0adb16cce7362802", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#ae3ca8eb03d9744ca16a42ace59dc9009", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#a6f2bb8857702c642a640b3be478e95a6", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#adcb128cfbe7bb8f696ebde31162024f9", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#aafa4a4f8ff54c9338186722556870082", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_died.html#a1781a8b818e55fbcda4e3a0b0f64a8f0", null ]
];