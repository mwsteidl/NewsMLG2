var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_event_struct_prop =
[
    [ "ConceptEventStructProp", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_event_struct_prop.html#a1a64df37c77efa0881c3d36786bd741d", null ],
    [ "ApplyToElementInternal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_event_struct_prop.html#a9afec2899961074f38cedad70660e67b", null ],
    [ "EventDetailses", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_event_struct_prop.html#ae69a66bce3f5cd054ebb4002becd2708", null ]
];