var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address =
[
    [ "Address", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#aeddeb4c0a60b4a9ef003d2f691709d32", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#af6447b4a4d999d00610858effc470528", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#aa257a5323456b7d1d601f9b96d496e54", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#adf711be08ce46ac42ca76a8ded735b25", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#ab4f1dbb4d537b26012c8b13052509a93", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#a418009a09d655e07677aab01d16d2e3f", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#a457859c6b418bd695a84abbfcab1bd8c", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#a91f2ce3df04e7305f146651f50014606", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#a1171233f0c3d2f3d2f17af039533631b", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#a1ab8e6bd1c241e18ba2e5619a3677c70", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#a2d5eaebc9496a1c61ac88a68b138cd19", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#a58497c2120c748669e9d435f33d33399", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#a41aad2976b130cd6dc64814f857b4927", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_address.html#a6bcfed593a641d010f1f077a99c25707", null ]
];