var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder =
[
    [ "CopyrightHolder", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#ab91406bd67c4f48175b23e541d96831a", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#ae9147d6df7b552e35942f01a81dc0ac6", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a93d77863cf256fcfd792149813bc32f4", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#ac8d8587c5e002823b90461e9a7b0a993", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a2badd17ce38523e14d004271513c89bf", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a7d8157f6aa40613cb034c60fb650b4a7", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#ad60a010933d1a87b2ed5007293eba60b", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a835a4e83b5760cb582fb9ba18910a58a", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a11ff2d4e07453377f6529e6a41114395", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#abdd22b47cd32433882d5e5b676bc9f5e", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a1a8d189cbf4a480d5c105b251505bcbe", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a733cf9be5572be93cc7f590e0ff4f9f7", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#af5095ae10d4b6efb906cc3d722fb7355", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a8160255cde8fa45322b74e828d08c8a6", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#affaeb6e4713dd0ae5f73aed9bc6e978e", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#af31484794c135cc58299fcacf6f6b9d2", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#aee1c497b1e230b4f2d386ed64fe229f0", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a806ce53279840aca8f3c18f6664942d6", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_holder.html#a93793fa581324f5010431782a01bf92b", null ]
];