var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed =
[
    [ "Embargoed", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#a9f9c0260e0f448f6ff9f4b8cdd6f7885", null ],
    [ "Embargoed", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#a36072c9549625fc556d1a4dcfac66347", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#a3779250ec1a3fe3b5107000ba094be6f", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#a96a49d54049d841b577acea0b8149544", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#aa11e9aae8c9b40f0152340c466f6823c", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#aebaf7e238b1c25f14d16295f7ad2b106", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#ac5194b50ef9fc1e522568df97cd4f7c4", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#a960abc6a4ec1bdf8ec40d24c6af8918e", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#aba5965501bc9d42345c2f02083efc235", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#ae9b7504959273d79b03d70acd8a8ac59", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#a2d5125708e52de0f7d8bf9c7a701d0aa", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#ac1ae85ccf785995135048d07707c028e", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#a780d6d0682eb207bd9d3c2057cc05a5e", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#abb0f29b74977f51577c0ee1f683ac319", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_embargoed.html#af34e32b395d7d4c9ddf953d00a27ae31", null ]
];