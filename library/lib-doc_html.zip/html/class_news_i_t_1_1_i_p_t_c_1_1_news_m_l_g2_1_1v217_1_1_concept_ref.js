var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref =
[
    [ "ConceptRef", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#aebacd0c9300aeae1923ba56203388866", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a85a05b7fee2021da676331e70923c0c4", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a63d9e2128b5b10c9077b67c13b840e50", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a60e900df78eee4d310c7ba954eaa4359", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a943745c62888ab0235c52ecc5e5f54f4", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#ae566cd309ae5dc2dd21927f8447d2188", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a81b6596f2ddd4144a2e1fc71fec756c1", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#ab9bae2174f8c394b73b0ce9698a46c52", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a48e9eca8eb27a067c48904c6981bed66", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a2f96a99bc234386daacc02dedbbdd3b9", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a4e72d5e61aeca083626ac9cb7c46735a", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a51917659489dafd4fb7d962480e810cb", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#aa1920fbbb17dc99857317cf123ee5002", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a54677fcc3d47b24826513005c6efe28a", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#aefa1c69c717cd4acbc21aa00c441222a", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a28ead54b048e3451f64a7551cb07c060", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#af0ecfcfeb81c7544d0963e7e78aa7e8d", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a1668c870904e786479ec49688fbc1637", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_ref.html#a1ccd2e41541ae1e55d505e599361c6df", null ]
];