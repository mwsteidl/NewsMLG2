var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note =
[
    [ "EdNote", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a12a977537996cff4673b3920b9844863", null ],
    [ "EdNote", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a4c2b413ff588fa29b9d85d2a3ef660a0", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#afff01a2c87c6729b0623e12f12a4e778", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a625caf6c2b892e6993a9490b983b3239", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a1209d5ba0f0e9eaca8ad73c15c9f2dac", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a868297c08422f6a2dfeffe29b5f84f9c", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a9ab59538ce46aab0aa17c5c8b080eb12", null ],
    [ "media", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a54ea70480dac54fa759c36baaa7afd0e", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#ab123eadad0503169131ecf74e717ff19", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a2f7dc13cbb423c21ca1c1d71b172f67e", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a438ef0c256a6544ed086b55ecb75c9bb", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a423a9f3494d4b81f04a6aa7f04c7f8c6", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#ae60096afbdbcddc94ec14a8040097df5", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#aa06d424aac7c21b5f95f9525df9380b0", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#adaff0599c287b426fd75b02755641502", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a0ecd0123b5a83612a34254989b7ac041", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a39558951230934e3d098431366b18be8", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a6306d9af9156263eb945fa9b8692fb2e", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_ed_note.html#a26183cdd4ad4043b13bdc989cd5b2e28", null ]
];