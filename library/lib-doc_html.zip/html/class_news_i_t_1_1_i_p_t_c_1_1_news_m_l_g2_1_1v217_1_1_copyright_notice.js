var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice =
[
    [ "CopyrightNotice", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a0389882540d436fcf44a0656c5a24f60", null ],
    [ "CopyrightNotice", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a20e2cbe7280a5be8b7b9b592a9c66828", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a6d660780195649a5aafc735902eeb206", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#ae1c3aa4f7d87372a99ae89b6c206ab28", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#ae1659b919ef370d2648dd7cf67f74e5d", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a62e2258c5e44adb6f62e088fee1b0d72", null ],
    [ "href", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#aa918276287fab0e7e8ffe1f58cea5280", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a6b381c8bc27238b5ca71984a3fff2b13", null ],
    [ "media", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a30b87d20c43fb3d114d12a7042b7b467", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a91fa1371ea90928f4a27729d17011e5f", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a25bb7c1d59ff32f536abad8d7f2d449a", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a77ba54bf66f352c2f2294ead527b08be", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#aa5339981385773d04b8249abcf404bc5", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a3d7565dd1678de0b4d1f26e4067a0eff", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#ac67c4c5335aaec0511902283a2dabe71", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a0df5f288dd7c537e4ddd5aec23157b2e", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a4596e9d043f1df81c70976e0e84d55e7", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a43582e64a0691e2a1b007eae1121cba2", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#a065d68563fd59d0eb81c4778c99d4fa2", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_copyright_notice.html#ac879a0454c5c34dfb436f1efb30ca9e8", null ]
];