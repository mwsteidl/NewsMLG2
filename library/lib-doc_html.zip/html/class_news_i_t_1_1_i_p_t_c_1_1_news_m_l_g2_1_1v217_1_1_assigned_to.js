var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to =
[
    [ "AssignedTo", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#ac12ae6098dcad9432fb2ada142684e87", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#ae5b22aa70d5fd4b2d640ec910ff1c068", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#add25f345f128b93bfee8bcf8ce6cb856", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#aa78b5f89a44cf46e2d646350f2f666a6", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a6d23c8508f2cffa291741fec019b751c", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a2e1c4e7d85dfdf92749d8a6378a09008", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#aac28fe82b95bd1cdfc2f244b8274ac8b", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a1d77ad09382e00e330d14e1c21cb314b", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#acabdba91119ea73f234ca359d08ca2cc", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#aa30b55fea5ffaf0ac5356758edb8c4d9", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a92f6e6401b0d6f63614ff3f83e02b496", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a438bdee42e10e47e533deb7927ec6cc6", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#adcd977fef1eeb91563c56b04e20facb7", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a7ffa0cfc1def1c7979753631a6d666f4", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a4c921e67ab909e85729090b2f4b776f7", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#ab2b33f31edcec71f2a48ce786ae1c1e2", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a1ffaf6237002b3b60ca8aa8e6320fee5", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a070931f4f8c8bee1c1dde26843bf9d57", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#a6f30dda05c83a985bb7172485def8bbc", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_assigned_to.html#af12341b4b4a560c63f18b5c3a2243b2d", null ]
];