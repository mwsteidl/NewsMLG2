var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_entity_struct_prop =
[
    [ "ConceptEntityStructProp", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_entity_struct_prop.html#a339b2dd55903514d43b21583fea2159c", null ],
    [ "ApplyToElementInternal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_entity_struct_prop.html#a090c6d053f9f9f8a4fdb067de629fe12", null ],
    [ "GeoAreaDetailses", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_entity_struct_prop.html#ace329e5047eb66bf453f7305bbd21e5c", null ],
    [ "ObjectDetailses", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_entity_struct_prop.html#ae2653c2e0029e1506a445df7711c5253", null ],
    [ "OrganisationDetailses", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_entity_struct_prop.html#aa7d05154afe411f181af9daa799de30e", null ],
    [ "PersonDetailses", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_entity_struct_prop.html#aeb23522578dc439ce11a3bf0269638d5", null ],
    [ "PoiDetailses", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_entity_struct_prop.html#a3c06ada79711d41af590b6621859c545", null ]
];