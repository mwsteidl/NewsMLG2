var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language =
[
    [ "Language", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a4e4ede2126a96bc7af1ae731d5a46dad", null ],
    [ "Language", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a43a4f39034ef292fb309c668807220d8", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a9278b23b875fcf335c468dc6f5a81580", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a6b44ba6225cf2e4c49fc0dd0176027bb", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a2ad784e01938856a32be37f939ce467e", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#aafcde096514075f04373f657675a81da", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#aa003ba319f44469c125f8141cfb0128a", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a5dcbd9bd251fc7a8ac8db7c1be4ac680", null ],
    [ "rank", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a68fbc5d3750f0c055372bc75466da3de", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#ae5a6a57589ff5d84c402e79296812c3d", null ],
    [ "tag", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a764480e3b4437b6cd05432bb9c42cd95", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#ada0ae77f3bd5b446bd502d48f85d9fc9", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a3afd7f6d3231b2f6552c8fa3c7ca514f", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a999d6a951463a7f9d5e137fc072a2a5f", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a42bd4559aba64ac7cb469072edfee8f4", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#af24813d8fc852cc5b50e1c0febf4b790", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#ae6bf530f0c1579bd265690c771aa81d2", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_language.html#a7a40d7c8694566fe1c1978346c0a87de", null ]
];