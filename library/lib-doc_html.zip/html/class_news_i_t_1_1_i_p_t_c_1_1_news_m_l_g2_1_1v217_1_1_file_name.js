var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name =
[
    [ "FileName", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#ac15c4802f9c7d516f29c7e149e9bb73d", null ],
    [ "FileName", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#abf729e7fe64b02e4292402dd99a848e5", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#a4f85a62da57d5938e4a210ebd4e27584", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#a9b6e024d730bb2d79b55db4d99eaa521", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#aa627e4c32e14a8b3e45e0a5c3187df49", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#adc5dc304388f2137ef2cc29b16836c92", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#a9dc33828835443fe919609c0297d428a", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#adb34426abbf2324d08632751e9fd3738", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#a8c191d9a07174182d371436041d6836f", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#a68d4c07cbc581be21d7c6f04b341d08a", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#a19d24f32cc65b337becbd1e77147eca1", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#a7bfe2e78e538e8e1790f07174df2fd9b", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#ab3aa1c07463afd703d39422558e64f64", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#afa41021eadfab32cb83a12283da808ea", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_file_name.html#a3eb82710bc093f9700178d9a2bef1adf", null ]
];