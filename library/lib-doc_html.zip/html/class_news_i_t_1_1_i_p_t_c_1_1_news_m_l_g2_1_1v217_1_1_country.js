var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country =
[
    [ "Country", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#aa98634c2ba769b9f6abf77dd54debd1b", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a711d4f00be8a90c3040c2baae1481229", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#addc7c97293289ad3f400017e7469d8bf", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a996e48ac4f745e243ab23f650e4243fa", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a07e51dd191127be08e5142ece29137bc", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#aba9c8240298341760b856543457bcb76", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a3a06f8a7effabdec975218ab848df81f", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a8c5d2447d933c93ae4f53157edb96a93", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a77e13c222611d58eeecda0d27fa53077", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a0c0a5c934f68ebd7755b9be9276ca9d0", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a03a2e9070fe62ae9c9e32de6759a7b49", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a0a4d4299ffe04c73f40664ad7b0504ea", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a9c8624f0768c02c8926b732fdf58eb1e", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a71ba36aa2174d25f34a09f921cd5ca76", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a5f0730fc371ed4c5c646c8c186b19b70", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#aa86364ff3b57a1dad246b9fd1cf4fed0", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#a8378c020bd64ad2c6e662e2b81ed3ce2", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#ae4dfa75b1b19856c8c58fa1fb602685f", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_country.html#ad653c264d40055d03e00d576ecbb49fd", null ]
];