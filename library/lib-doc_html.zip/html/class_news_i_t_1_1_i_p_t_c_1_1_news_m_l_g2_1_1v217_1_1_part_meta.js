var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta =
[
    [ "PartMeta", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a889c1128dcbe842268dda9d206616e19", null ],
    [ "contentrefs", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a5abca7eb7660eab3263728032ac841f3", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#aa1dd79c66017653fecb0978094ca7cb5", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a5bd79c589d26a1813b76295b8d4d8907", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#ade59d09a16a5f5057079a7c1b2bbe78e", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#aa5dbeb4b9eccb13eda8259eb5b8f16f9", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a47b85f48459b1d41dfd696c7349ad1ad", null ],
    [ "partid", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a479e8a46bbcf68fd7edb37722764e9fd", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a8e8db2d7e73b1e17aa1df93a1fa78ec2", null ],
    [ "seq", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a12135925f04c63c3a904fb30c76086f5", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#aa5fd16e3b97c5d48423b2ed47380e11b", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a8346e6751de5acd3283b44008c9cc484", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a342513e87359a247788a363be7dbeff1", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#aef0820c6d3e38e63fc7066c1bc4dc6cb", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a906b6a8b9d50fdc3c30754f5dfcda38f", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a4535025b6c9bc356f35c57bc6a6fda87", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_part_meta.html#a0d6a3b538ab375218f3528dd71efbe36", null ]
];