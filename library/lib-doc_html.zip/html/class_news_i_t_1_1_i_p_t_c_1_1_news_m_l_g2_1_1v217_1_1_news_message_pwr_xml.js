var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message_pwr_xml =
[
    [ "NewsMessagePwrXml", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message_pwr_xml.html#ade05ea5d66b9cd23999bb951bff7c1af", null ],
    [ "AddItemToItemSet", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message_pwr_xml.html#a1b6c13ff3334ab8ce9949ee3055bd6c6", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message_pwr_xml.html#a7ab30b0121a8dc496e75b7c27c80dd7b", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_message_pwr_xml.html#ad7a8f40f16516e16709b620f02e4fb22", null ]
];