var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id =
[
    [ "ConceptId", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#afc579d0e824f8bec4b398c7777577aa8", null ],
    [ "created", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a80800d0b46d94119ec6f5e7f89a82953", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a5ba84931e2d789455d5fbe4063632bb3", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a8bd90b0edb71739963862f1ed73906da", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a0894228dea15c03df0b9a7990a78bccc", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a7fb250e6a66ebfeac19bc65dc7d3c2f9", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#ac944ffb5746cae0e30fce1bb4cb6f29d", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a62e5c831dc7af82f43eb2abf143a5c69", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#aafb17d05a55ae981e7d92e8424de806a", null ],
    [ "retired", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#aa117b5321cf85f7b648d8a1b209a74ef", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a40570725f0170ae5bacbac0e9d67e61c", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a52592f22bbf8e3bc0c9b00cf93e7c3e1", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#abc065e3ed0a20b566987e0b19753eec4", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a553b232904a3c1cb1e63e6243ddec379", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#aa4857a5305ea34c77d26c1c483d1b2f0", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a4a6dafeaf5c9f4fd36f4f782f41cb023", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_id.html#a28dbdf034d1ef3dea0011f88100ac294", null ]
];