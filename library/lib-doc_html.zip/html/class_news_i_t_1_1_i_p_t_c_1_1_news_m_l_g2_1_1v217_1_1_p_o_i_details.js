var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details =
[
    [ "POIDetails", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#aaae0f69d09dfa44b03ad3b4345bf730d", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#af836cc2e8ed13bdb2775349d0c20cd01", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#a962f3db25ebfe66a11e78eae26d3b106", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#a0e2d96811867c79bf1462630105ed61b", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#a96530979934c6a4c7c7c08bdcae0d6c0", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#aa6ee91be64140cabb075555e6f12a64b", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#ad5868b748265d9cb2fb11af03eb0375f", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#ab027292980217b50f72a79f96b820a53", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#a12f79dfb5d31e6959aad3ab39d0eae1a", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#a3ef89b01640943bd507a07617c0bd913", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#a1c813c6d34fb91316bfa542c5a1efa3d", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#ae31f632631a1afb752d1994ac9e583e1", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_p_o_i_details.html#a97c136491b8e278d0d8e6fe5cd429bf1", null ]
];