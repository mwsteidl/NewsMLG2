var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located =
[
    [ "Located", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#ae482d3d55e2803194ceff306906752d0", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a38a74ec0758c65543222ad08e619527e", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#af1e5e6a3195a3db3ed5339207be400c2", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a2a44bb1b70ee78be129352bd250bfc80", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a24e06983b15bbad2017423e56ca530c2", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#ab5d0c7756ffd11960ebc7a82015c5cb0", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a7bb6ec6d6fb15a3263b92ad5f67b5681", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a2f251c7dddb3c14be6c10e063a95a979", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a0ae39afe6275146d023771fcd5239a92", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#ae8c7239faca190e70c7f26b265d33bba", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a5bcb7f1194a46bf3fdab5eef3f7c7b5c", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#af7f75bbd6041766d9eee61ec7d54144c", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a2bc78fd91bc5c86225ad5a2c6018b059", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a364fedb0f0bbd090fbc81b3a6ad1c4bf", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a64e2d0de847c2c91d91cc4356b88f18d", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a0eedc708a0ee07584fc8005bc886f021", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a2305c3d73314fc0abe588fdd0a83385b", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#afda807105a927874dd0468c90d61614c", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_located.html#a2a4aa50fb8780ffc70f4f358a5bd9208", null ]
];