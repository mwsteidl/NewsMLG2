var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item_pwr_xml =
[
    [ "PlanningItemPwrXml", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item_pwr_xml.html#aac92856a8aec37395bff7768f02c3eca", null ],
    [ "AddNewsCoverageSet", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item_pwr_xml.html#a22ee44f3d20abee5d5328a3879c3d8f3", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item_pwr_xml.html#ae9d15e9045bd2146a3e3fc26294f0faa", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item_pwr_xml.html#a3d5fd3aae6fd3917a5e5b9a1c05bad9b", null ],
    [ "NameSeqPliNewsCoverage", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item_pwr_xml.html#a994aed4aecec96ef102434a7390fd395", null ],
    [ "NameSeqPliNewsCovPlan", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item_pwr_xml.html#a4b8bd06b456b8c71bc1ee3c8fc35b7b7", null ],
    [ "NameSeqPliRoot", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_planning_item_pwr_xml.html#a0146eb8bd836cc2aaf84b695c0dcdf5f", null ]
];