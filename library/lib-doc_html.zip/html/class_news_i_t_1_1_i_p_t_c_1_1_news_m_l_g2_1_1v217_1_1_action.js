var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action =
[
    [ "Action", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a8914d002ff1f4cfc58806c576375e531", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#aa17d3b8cd83697c6d3fd4f6de0a18775", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a9ebee1feb22b0c07e6ff4ac0d2564e0a", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a741d723d1e3bd8f41150843d63da2fea", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#ac4c01dbc03ac4bf053581b48e59f4258", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#adf2e459fb55ca8d11ebe1d97e74da1f7", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#ac86a0e7f9ac52db51fa16cc9eb9c2570", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a7b0b90d0ee6f5d6eac58900abb5d2aab", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a04bcaf1ffafc0ea69a38560f1862425c", null ],
    [ "target", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a3a3588d4a80b3d98aef919b4ec3b156a", null ],
    [ "timestamp", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a393375819798ca8ded08c2ed742bab4a", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a930dce742a098a84cd2d4eb920e66f9a", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a0cf8ecd5312e534b13c0294d66fea263", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#ad16fc93b825af24c4188c95d0905c2a9", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a207366a5ba712f2baf9857a9774afe9b", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#a521467b04776825695668695ea63acdd", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#ac6cfae8d5947547a4566d4d6bd622250", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#aead970195d49a8b11d3abacefdca5217", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_action.html#aeaf32631acf3f8e49b2c39a5374a2de2", null ]
];