var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta =
[
    [ "ItemMeta", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#aef3816ba966dd12241f8cb77a9acf501", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#ad85eb17377463095a4173f865d6c0cdf", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#ad66e85506e5e36e920ee4cdb7d92fb6a", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#ae4dd21c7e02aba5d9eb34bbc146e627b", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#afb7ffa6951c918e6d193959e7868778f", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#aa811c9fe8eed57c7450f0bc9d776c8fe", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#ae52c777c1a20effb511b4bd31a3f54a2", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#a201a67029c2574e627d5c160e0b13e82", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#a9f733a4335cc5c05baf56b72bffe6554", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#a9b80b4503bc3224083b0d128485d9208", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#a260bdb900727106e5767210920da9884", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#ad7287c6d3a610e795bbc789f1fbc2f6d", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#a06163bca264fdd32506857180a43a1e8", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#a2d347e7e668aad0d020e709b292ecb5a", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_meta.html#acc1556c5a33007f8c3bc4c54b86080bb", null ]
];