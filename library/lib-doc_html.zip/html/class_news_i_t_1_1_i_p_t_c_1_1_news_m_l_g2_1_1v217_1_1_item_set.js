var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set =
[
    [ "ItemSet", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#af219ef9a63f501a80b7ce61c3bcda22a", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#abd4c08e81fd1487544e1d79681c7fc6a", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#ab2f7056e459d9d932aeb7a6a33ca214c", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#a63abaa2e59b2d0a84276e3ca01da2314", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#abb45ea446185f06087e268c26417df5e", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#ab1c6f711cbe840606d6924ac1cd73684", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#a4c2460ccb8640d26acf4720e4d129773", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#a3daeeb037b48e9ddfd04eecda64fe241", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#a18f8769d4745ee5b4faa23506edb3f3c", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#a7e9493af76f786e7dbffe9bab2c70634", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#a40b901b40cc3e0db4d5d81bcc7424ec2", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#a78eba39daa13dea1e781f49701ada896", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_item_set.html#afdcf703921f8afdc36aedc69839baec3", null ]
];