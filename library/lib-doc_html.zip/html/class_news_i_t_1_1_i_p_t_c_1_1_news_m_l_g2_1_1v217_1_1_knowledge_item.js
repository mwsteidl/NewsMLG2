var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item =
[
    [ "KnowledgeItem", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a24711946d82f591c3b92329fa22dc658", null ],
    [ "conformance", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a89c7731ba03a692b1be974cf8165b802", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a86e0779cd24f19de5a08aa58d4de816d", null ],
    [ "guid", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a978d2d738a6b0ae2d3f55409d2258dc7", null ],
    [ "standard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#aa433b78877070f70002ccbb45cd25a7c", null ],
    [ "standardversion", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a2dbd6d292c5ab552a8d676e4f7998337", null ],
    [ "version", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a763e18c156f49bf17087aa6fa5489523", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#ad7a6cd16c5f967b2161f2da871645065", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a0bb78609d0e0abd043974e8b5c75eae7", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a4b854b5a1ffe60b0f3d6c797140753ad", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a974938d13882a31cd630743088390ae7", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#aef1f97c82982427cc66ead1f3654dcce", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_knowledge_item.html#a21ec555ffb4b8e7ab36b22541bb16d96", null ]
];