var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set =
[
    [ "NewsCoverageSet", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#ae5e11fd3b61d83005961f1a18f15ed83", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#abc66fd210555fa85b1a8da2c50727d70", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#ae1e5f9ca7278f2c426d8352ab8804e4e", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#a35be88c2ce8e6ad715676854d59ac8bd", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#a8a3814722ef4c0284d2acd21a2cf621a", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#a05c0cd4a606ff6a29a55c5683ee99c6f", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#a52e63e4edc548550a92e7f0aa73c7fd7", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#aeff27c1df7ccbcbd4227ac94bcf715e0", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#a23e8233030f7a80d5ea447d4f5f14bb3", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#a24ac9db026ae294d42c589b9fec94058", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#a2d81c82905f30bb8319fa6375ea927f3", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#afe5fc6b28b74bfa460f4dd0333ca65bf", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_set.html#a1d47c927baf3b09dbad6253c25d7f311", null ]
];