var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc =
[
    [ "AltLoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a5f6cb9a6104c682b8838e7cbd722f1b4", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a560074b68477ec8a0b12123022c8ab2d", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#aad7ee7e5f5ada867fcedb3f57c6ab6ba", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#afcbf43e12d59fd2bf25c8443ab052664", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#ae8f0ef2fdaa3476256e9eda6b50cfae3", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a711cbb34aaf3c0d916437bb6c7f0bc57", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a5aa1eed46eccbdaaf9e05e0de5b3e2ee", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a50be1e51034e09a4d9b6d334a50d1971", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a173c6c93e900e323a5882f09c166c7a9", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a00f3763ce07372d4b627db91ea17ba59", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a86e0b8673d48b43505da2e35c9a93481", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#ab3f9f1120d85467a81b3c9c486d2a75e", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a3bb01faf8c919864626b6ef81d0c52f7", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#a98c457d6e6688edabaf0738d0a14ab13", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_loc.html#ae7c383ebf26b8001f49ebceaacb2d66a", null ]
];