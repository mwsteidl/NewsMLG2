var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events =
[
    [ "Events", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#a0c4a672da9224ab1658ac7c8c0d96ac3", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#a1b2366e9000a2ece5ece6beec2716647", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#affaed85febca52bd5f136b27de9f9030", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#a821ebd918d4b176159ef2ca325a4bdf1", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#a8c8f9b039c5d937f5872ddb7b9a9d033", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#ae77fc46a6601658170533cfff2be8048", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#a4393aa40aaea521c035deaaa3f86f644", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#ab7a1e30daafab54e0c5a009b46cb367f", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#aad23e5d48ae5360328d9b3bc4e79edc3", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#a0b505e3210cd59d9f7630ab915b6e027", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#aed58e3ed608b49af3c703e0922d45707", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#a37860bd220f96ee294a0de1903694324", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_events.html#af8cd8d2d1400b5c97cfd51daf19dad85", null ]
];