var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status =
[
    [ "NewsCoverageStatus", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#a85d9cbe4733261f51bb8c973a1a8c468", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#ae74c10828186f5657b053b88273b87de", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#a93f8c5b9b9ef804b275aa089ecc8034a", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#a051a641ada20f3596cfdc9401456623b", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#ae50fbf1199c37c7a6452f2ea04c7ce99", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#a171704c94c3e543468cca0dce308bf6f", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#aff67366479f88c62b6eafc329efd3ac2", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#ad2e1cd660a31e177ff3f1aa57452149b", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#a1305cf72906b8e31d878a134090ef343", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#af64c9d3bcb67dc817f9ad093780daefb", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#abf6a7afe4e7677340905dad1e07e2ed7", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#a9196c7647660ec3ed88a654ab60fa2d2", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#ade0d9f0cd3e82e7e9a45c5f44b97dd1f", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#a4878d3d16f2780261098b19596b617b2", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#a3392f1683abf1df4e36c019401b10b5a", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#aa3a241d6a0748f1122b0fb790a966096", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_news_coverage_status.html#adef5d91b2ad7568d187b041eed0fb2cf", null ]
];