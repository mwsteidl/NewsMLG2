var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item =
[
    [ "ConceptItem", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#a77019bfc75e2ca3e920aed937d48cd9a", null ],
    [ "conformance", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#af6f1b096c30780a32ef506032072041c", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#aaf815bbf52c9a667f576c6518d9bba53", null ],
    [ "guid", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#a108d161f4cfb7b47422d73cd81aba672", null ],
    [ "standard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#ac1baa30d2e767c5839f2365a2e7051e4", null ],
    [ "standardversion", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#a484190a4e0d5105533f9f9a5d522de9f", null ],
    [ "version", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#ac361ce25e9d1e9ec76b6087cc60af42e", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#aa297900ccb6235e231e0e1e6296b6d23", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#a556aaf39137367f11319d660cfb493b0", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#ad9fa40ea05834a3fedbf4c715573b629", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#aa0d0a5605f9bc4e2c4e3ea0efe2789d6", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#a54bcd0238c4c4abeaecae5a59dc44728", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item.html#aeb350efdd0f24b2f8dc98b4b2d9f6597", null ]
];