var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of =
[
    [ "InstanceOf", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a20fcd26604fa582ccd173682bc5e09fd", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a4148e874b9e4f87df16213a5adfd307a", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a5d31ad011784c1c0ffda7aa815ff8606", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#afe52b0d0ce9dc4428ffc6d38502ac777", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a388ab590c768f93d6ef66f37baca25fb", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#add5d1a4be2daf9b15cb1fbb2b983747d", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a3875d1cd09cf7104ac8f0c28c32cca5b", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#aafefeb4da0a47d515dbecdee023021cb", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a679bf0535155ab9d86fb71290cac7e58", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a9e9f118bd0c98d383c9a8a2bf70a8fc6", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a477bd2ba02dfedb3071a2c9288327082", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a374ec24f7cf4b550ceda36a1aa86b199", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a58b8a855573f9141fdfb8f73c3d14343", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a168250cd1a1cf0c91d0162aef724f8cc", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a57c8bc5838cd8cccbe1685b7fc6c4c72", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a48cdd68c4f79fcf532b2c70130232c51", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a20d029157af12c3c3d68d1fd47f5d3b7", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#a0b0e4b8b1c5541a4e655578332c0f091", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_instance_of.html#ad9820ef22170cab0b5441b5cc43c0b91", null ]
];