var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item =
[
    [ "PackageItem", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a43b1a18c03fde30ffd2166d18a6c0358", null ],
    [ "conformance", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a63b266210838eb6aac9c0445b921172b", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a5dc1eb9c632173c658cd5de714bc4115", null ],
    [ "guid", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a1019e65097867abd04ed759adc055ec9", null ],
    [ "standard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a219f65dc48297c50ca2844f7aba203fc", null ],
    [ "standardversion", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a5c5000381e819abe75c9771775088c39", null ],
    [ "version", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#aee8dcdbb2e4e1262eedb46f9b6e75636", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a1dbc36d8d80969bc400e52f493330482", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a761172c84e6d986fec83bab81ffa12c0", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#afac9cea9d65bbcde88ace40b8a23c563", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#abc6b6720206d4aa596d36b0354d4247b", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a5414b50422832412df3b2295b10ee0e2", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_package_item.html#a16b6ed8204dc95947a5e6204c3b2549f", null ]
];