var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref =
[
    [ "CatalogRef", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#ad8f398e6c32ccfed838fb56b9305e1bb", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#a590f37f2a3f9dbb0af528fb83cf380db", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#ad4ead2a99c9da35a08ce90758799dd53", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#ab14c8f247ed4f8eabe1eef4f1b9a4a1b", null ],
    [ "href", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#acd8aaa283d6a3a2266a50dbf92ea0475", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#a4867a559a40a7a8b112df8c19f604fb6", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#ae96ac05dfedda7117fd44f99e88ef794", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#a93a5230d23bab2edfef3ff1aeeec9ecf", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#a8c66f282340eec49e95259e38cfcbd22", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#af7a29d28012129844c994d8bca1c182f", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#af956a1ff4922c60a87ccc063847272da", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#af451c75e6538bf7423d41058be9b6167", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#a02115a41df86c77e1d9ef9f446bbe956", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_ref.html#ad2d0b494d0056ef97443c9c7ed0e6b82", null ]
];