var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle =
[
    [ "Circle", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a2f3ce70949a9bb56df80e0bbd6f390cb", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a628984fce03b914561a205e3ef6de858", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a536de2826c8cd964dde4babfa0e8bc45", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a13baf1adbeeecb9cfa10d53030f82a5e", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a37a97ac573738dbe124415990f651834", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a40cadf4b9bf35a4d8209717d62b3ec34", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#ae5a30e6eca82de259bee86040d7220a3", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a6c9cb2644b022b05170794e82a5541ea", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a68ed82c28c9cb52da48f5aa492a098a5", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a3de14b832a7b3f5662f290389f3229db", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a089be20b2ac319f5870a80f9cec051b8", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a090f7456baa64b241b8ad24c5e93c931", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_circle.html#a3ffce5dd9d6ded8aea73a66319aaac38", null ]
];