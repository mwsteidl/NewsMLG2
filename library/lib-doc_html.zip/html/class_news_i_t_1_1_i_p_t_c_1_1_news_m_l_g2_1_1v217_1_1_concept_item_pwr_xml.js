var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item_pwr_xml =
[
    [ "ConceptItemPwrXml", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item_pwr_xml.html#a5be613a0958b31d8460b7dcdb1c5adee", null ],
    [ "AddConcept", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item_pwr_xml.html#a57b854c589203bc0e8224f3c903d550d", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item_pwr_xml.html#ac845f53f7d1cb1ff77d4499f74dfcb62", null ],
    [ "InitEmptyXMLDoc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item_pwr_xml.html#aeebf3e8a115ebe5e2c6fe3e1a653a418", null ],
    [ "NameSeqCiRoot", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_item_pwr_xml.html#ae0e111b54fd0f8c4b764987d9593579b", null ]
];