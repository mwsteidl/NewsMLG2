var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep =
[
    [ "AltRep", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a172c148a360c1ecf266d0fd6b5a2128d", null ],
    [ "contenttype", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#ae7207850cee799c8027f3a4ccc07170e", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#af7e313ddfc8826c705536f7e0ecfd9f8", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a6fe525608720a1470c82550a3763d190", null ],
    [ "format", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a72fdc55f04f29a6ea7ff3bd5aa1289ab", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#ae5d10c36f89a61a19b5f651f7b2915df", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a253a80f1a1bd64b100df33812689985b", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a24aa2db64f4328ae7e5c8d6a040dee59", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a544433491592d31f62f313f2f67cc1ee", null ],
    [ "representation", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a96fdd2302191d216b807be5a741e12b8", null ],
    [ "size", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a98e7aae48c5383e158b129693ce4b464", null ],
    [ "validfrom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a60a013e6291c038093acafc1d5a087ff", null ],
    [ "validto", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a643bcf208d8ef6d9e144fb8f840205b6", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#addaa84e2af7ed7d4a04706b080a323e5", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a0da58e7d46c74f69d8389f39cad087df", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a949b4bb3055eda533f81c97e04aae766", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#af03af02e7d2ea803f01459cb79306c68", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#a2e0323902d86a9217617ecc50159a367", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_alt_rep.html#afd77c9efc9d05cdbf2db7409a77470b2", null ]
];