var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop =
[
    [ "ConceptStructProp", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#af60b326a39c9387af462d50d0452a894", null ],
    [ "AppendAsChildOf", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a9e6ca52d7ca336c3ca912259ab09e921", null ],
    [ "ApplyToElement", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a98ccd83a5b0dcb3c20c1d24c0cff1bef", null ],
    [ "ApplyToElementInternal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a5af8f4cfa5788f44786fecb3b90ea0ce", null ],
    [ "Broaders", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a163a8fb83ef7d8e5f45ede1c0114895f", null ],
    [ "ConceptId", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#aa71f92d32ff691d7f94e6fa306bd2708", null ],
    [ "CoreConcept", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a99b06eec90504466b569be42178a582a", null ],
    [ "Definitions", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a169137b0342b8c8f2b5bb7b1e781a257", null ],
    [ "HierarchyInfos", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a432d5292cd6d9a9774199a0a449f1cac", null ],
    [ "Names", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a3b55937b74fd604ccd25962250a64c14", null ],
    [ "Narrowers", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#aabd6c9554a80ba3d438c2696e48d1c3b", null ],
    [ "Notes", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a0653cdc33f5c8d74b6655cb287df0972", null ],
    [ "QCode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a76581595d07c99f5a482de026c3b02d9", null ],
    [ "Relateds", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a0295f18eaf8e93853883af213518aaca", null ],
    [ "RemoteInfos", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a417f548b197fc8ba110f89d42a52fbab", null ],
    [ "SameAsses", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a1b50503d57fd85d12ba59f38cb4e0fc7", null ],
    [ "Type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a86e9b223ff5e21d30d03caf9cb1fe3a0", null ],
    [ "TypeQc", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#a4abcc5a6a970adf295562d6c4be0f659", null ],
    [ "Uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_concept_struct_prop.html#aee0f9d76421683b60c8682f0e5520037", null ]
];