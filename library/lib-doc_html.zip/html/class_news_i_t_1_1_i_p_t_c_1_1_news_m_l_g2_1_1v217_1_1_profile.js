var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile =
[
    [ "Profile", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#aded25f78a2324940db29a4bce36d2a2e", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#ab4d8a73a5c63a8ae176310b84b48ca3b", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#a515c33fea35ef9d7099cd0498160ebf7", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#a3ca6560369c1b9d267b54c5e7df7ec75", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#a7b902e7ddd5177eb9847536fc4ca9228", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#a35be14421b358e7493464db9f23dbdf9", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#a1e93a27191e0e5d0c935abd851f2e686", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#adb5e5669cd0f2781bfcd4a10731e65d7", null ],
    [ "versioninfo", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#abfd4d9e96a4cb0b8d056407822b41ae0", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#aa3b6a1b8fa09c7b504b7f619fa149861", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#a970b1a5c61698207a19a5213d75bf916", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#a0673065da0a0275719063bc04c45d95b", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#a8fda3c976e4dec059ee848fba2fc1dce", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#af0f932d6a2de11912b5da1409e5b5895", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#acf8d13a2ad7ac8fc0f161c225bf7f48e", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_profile.html#ab526f94f32deb92a2c47db4f00ae51af", null ]
];