var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location =
[
    [ "Location", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a405cb210f535f867a254c9e26bec2ea5", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#aed07b07dfd97178063b02f50e4be8b6b", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a96de0b63ba5e6b2630f6abb43019e140", null ],
    [ "dir", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a163a6777cedf8f9dfeecf3c89a87a86a", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#aa16a3154fbbcaee1eded3edd7814fe29", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a88cc7e563984233ba9c3fb3786620563", null ],
    [ "literal", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a9c7881d387e3128fef289776435a8763", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#af8f98bbb685bfd193e704322018f3b4c", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a79318326ca99f7578f44039c245ccdda", null ],
    [ "qcode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#aee5b7dd6b0063d0d42afa619943a0a7c", null ],
    [ "type", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a16caa44eabe4ffa5442e9b8a7d73ce64", null ],
    [ "uri", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a54fdcea330a4bbc2ef1c227cef3497b5", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a5290ae3849a3556ecaf56ed406e8149d", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#ab78a33b1bed33f0ae6b4cb5b67343e22", null ],
    [ "xmllang", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#aa7629bd9ac635ee3416f4438d1ac7174", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a97333526ef85d6f6a08d4783f0fcd05c", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a842a3dc42e658164ed7362eb111a1468", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a283804f7e0ad6e6384267bbd4cd96fff", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_location.html#a1310993ed5411f2fd6d445355c7872cf", null ]
];