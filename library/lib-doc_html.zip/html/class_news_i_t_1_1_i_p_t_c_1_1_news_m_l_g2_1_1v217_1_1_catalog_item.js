var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item =
[
    [ "CatalogItem", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#aa0552d2cfb7c4a7f1bfe2a9e3f008862", null ],
    [ "conformance", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#a6147aa7fe032bea30c2eab472a2d3712", null ],
    [ "guid", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#a9631a6b1309ed93b7b4b9a9a070048e1", null ],
    [ "standard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#aeca99cfe79ab834e5e67ef105656bb9a", null ],
    [ "standardversion", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#ac07d5b960bc8264725fb347fa9064b1d", null ],
    [ "version", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#a18ace89f408410f5fd029a7aaa29ddb2", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#a77435f075909b4dc27f96eb8d3daf1c4", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#a6e38bdc5d4c63964f85ce0b8beba7660", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#a0b220880079e7a1e2ba5fe512981872a", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#aa1206ceaac548390e6296cf6c2757d56", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_catalog_item.html#a518a426169c8825c69ba40723e17d9e0", null ]
];