var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email =
[
    [ "Email", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a0725aa65db2ad3c695c1a4a7ba57b667", null ],
    [ "Email", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a82565b135eb351fe1da775f02512bd27", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#ad389cb5c0114ace8e9253e063e893eb2", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a372713a8c6b9e0bd3f9f5aa3d601f69f", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#ad55d5a763a9560ad048b867b752f45a1", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a4a224bb29f962a30c886ca4e35c3fb03", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a65c20aba0e8f128b6ae98f260bb61bec", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a92b3c190fc26add07411fc6bef7c4e18", null ],
    [ "role", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a974bebc13b0c3f1f9a37f9e2c8661698", null ],
    [ "thisValue", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a4c8d9517d8a72d29671174d185c094f2", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a4fa25315086a38489fef64798d03c338", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a47f84e1dc7a992ef278501d58140626c", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#af5e2cfa24cf0c2a14c2f21c3e0716ed8", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#a8cc137c1cb7229551351ebde44fcc621", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#aa2340b64df58de5ee3a4723c9ae94199", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_email.html#addb3de5920e3ef0a74c9bab7e2b6934c", null ]
];