var class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery =
[
    [ "Delivery", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#a3bc58f52fbcc5ab5954edcba074a627d", null ],
    [ "creator", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#a0fe1fc85bf6d92875f8c648a4550f150", null ],
    [ "custom", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#a877d0fc7d79d6254be8e4e53c42c1174", null ],
    [ "how", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#a30e24e1f08e636c37e52b8897844f843", null ],
    [ "id", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#a431b598ed6bbade9fffb4304128d8de8", null ],
    [ "modified", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#ab8d9e7705b473e1c97ec08d1a9f40e3c", null ],
    [ "pubconstraint", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#ad20eaabb966416c33dbabc65085eb189", null ],
    [ "why", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#a4e3ee2eab2e0d6d4753aa5ade638faac", null ],
    [ "Xcard", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#ac26186595d09b408c2c4ec42f3245b8b", null ],
    [ "Xname", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#a876fdafcdfbf1e6ce53661e639248d23", null ],
    [ "XnsPrefix", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#a03b27059416d7c72f68368675830b4ad", null ],
    [ "XnsURI", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#aa66af56711494de342992964ebfb3410", null ],
    [ "Xusagecode", "class_news_i_t_1_1_i_p_t_c_1_1_news_m_l_g2_1_1v217_1_1_delivery.html#aa950af14c9bb275c3b3e13ddcb1e7f51", null ]
];